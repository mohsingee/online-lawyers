@extends('admin.layouts.master')
@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Send Package</h6>
                    <a href="{{ route('users.index') }}" class="btn btn-sm btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back
                    </a>
                </div>

                <div class="card-body">
                    <form id="packageForm">
                        @csrf

                        <!-- Users Dropdown -->
                        <div class="form-group mb-4">
                            <label for="user_id" class="font-weight-bold">Select User</label>
                            <select id="user_id" name="user_id" class="form-control">
                                <option value="" disabled selected>-- Select User --</option>
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}" @if($id==$user->id) selected @endif>{{ $user->name }} ({{ $user->email }})</option>
                                @endforeach
                            </select>
                        </div>

                        <!-- Mode selection -->
                        <div class="form-group mb-4">
                            <label class="font-weight-bold d-block mb-2">Select Mode</label>
                            <div class="d-flex align-items-center">
                                <div class="custom-control custom-radio mr-4">
                                    <input class="custom-control-input mode-option" type="radio" name="mode" id="one_package" value="one">
                                    <label class="custom-control-label" for="one_package">Send only one package</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input mode-option" type="radio" name="mode" id="multi_package" value="multi">
                                    <label class="custom-control-label" for="multi_package">Send multiple packages (user will select one)</label>
                                </div>
                            </div>
                        </div>


                        <!-- Package options -->
                        <div id="packages_wrapper" style="display:none;">
                            <label class="font-weight-bold">Choose Packages</label>
                            <div id="package_options" class="row"></div>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary float-right">Send</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('js')
<script>
$(document).ready(function() {
    let packages = @json($packages);

    $('.mode-option').on('change', function() {
        let mode = $(this).val();
        let html = '';

        packages.forEach((pkg, i) => {
            html += `
                <div class="col-md-6 mb-3">
                    <div class="border rounded p-3 shadow-sm">
                        <h6 class="font-weight-bold text-primary mb-2">${pkg.name}</h6>
            `;

            if (mode === 'one') {
                html += `
                    <div class="custom-control custom-radio">
                        <input class="custom-control-input" type="radio" 
                               name="package_id" value="${pkg.id}" id="pkg${i}">
                        <label class="custom-control-label" for="pkg${i}">
                            Select ${pkg.name}
                        </label>
                    </div>`;
            } else if (mode === 'multi') {
                html += `
                    <div class="custom-control custom-checkbox">
                        <input class="custom-control-input" type="checkbox" 
                               name="packages[]" value="${pkg.id}" id="pkg${i}">
                        <label class="custom-control-label" for="pkg${i}">
                            Include ${pkg.name}
                        </label>
                    </div>`;
            }

            // show plans as small badges
            if (pkg.plans.length > 0) {
                html += `<div class="mt-2">`;
                pkg.plans.forEach(plan => {
                    html += `<span class="badge badge-info mr-1">${plan.title}: $${plan.price}</span>`;
                });
                html += `</div>`;
            }

            html += `</div></div>`;
        });

        $('#package_options').html(html);
        $('#packages_wrapper').show();
    });

    $('#packageForm').on('submit', function(e) {
        e.preventDefault();
        let data = $(this).serialize();

        $.ajax({
            url: "{{ route('package.send') }}",
            method: "POST",
            data: data,
            success: function(response) {
                toastr.success(response.message);

                setTimeout(function() {
                    window.location.href = "{{ route('package.assigned') }}";
                }, 1000);
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    if (xhr.responseJSON.errors) {
                        // Validation errors
                        $.each(xhr.responseJSON.errors, function (key, value) {
                            toastr.error(value[0]);
                        });
                    } else if (xhr.responseJSON.message) {
                        // Custom message (like duplicate contract)
                        toastr.error(xhr.responseJSON.message);
                    }
                } else if (xhr.responseJSON?.message) {
                    toastr.error(xhr.responseJSON.message);
                } else {
                    toastr.error('Something went wrong!');
                }
            }
        });
    });
});
</script>
@endsection
