@extends('admin.layouts.master')
@section('content')
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Assigned Contracts</h6>
            <a href="{{route('package.choose')}}" class="btn btn-sm btn-primary">
                <i class="fas fa-plus"></i> Assign Contract
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>User Name</th>
                            <th>Email</th>
                            <th>Package</th>
                            <th>Assigned On</th>
                            <th>Status</th>
                            <th>Payment Status</th>
                            <th>Last Payment</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($users as $key => $user)
                            <tr>
                                <td>{{ $key+1 }}</td>
                                <td>{{ $user->name }}</td>
                                <td>{{ $user->email }}</td>
                                <td>
                                    @foreach($user->Packages as $contract)
                                        <span class="badge badge-primary mb-1">{{ $contract->package->name }}</span>
                                    @endforeach
                                </td>
                                <td>{{ $user->Packages->first()->created_at->format('Y-m-d') }}</td>
                                <td>
                                    <span class="badge badge-{{ $user->Packages->first()->status == 0 ? 'secondary' : 'success' }}">
                                        {{ $user->Packages->first()->status == 0 ? 'Pending' : 'Completed' }}
                                    </span>
                                </td>
                                <td>
                                    @php
                                        $latestPayment = $user->payments->sortByDesc('created_at')->first();
                                    @endphp
                                    @if($user->subscription->status == 'completed')
                                        <span class="badge badge-success">Completed</span>
                                    @elseif($user->subscription->status == 'pending')
                                        <span class="badge badge-secondary">Pending</span>
                                    @else
                                        <span class="badge badge-info">Active</span>
                                    @endif
                                </td>
                                <td>
                                    {{ $latestPayment ? $latestPayment->created_at->format('Y-m-d') : 'N/A' }}
                                </td>
                                <td>
                                    <form action="{{ route('package.destroy', $user->id) }}" method="POST" class="delete-contract-form" style="display:inline;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
@endsection

@section('js')
<script>
$(document).ready(function() {
    $('.delete-contract-form').on('submit', function(e) {
        e.preventDefault();

        let form = this;

        Swal.fire({
            title: 'Are you sure?',
            text: "This will remove the contract assignment.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    });
});
</script>
@endsection
