@extends('admin.layouts.master')
@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg border-0 rounded-lg mt-5">
                <div class="card-header bg-gradient-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="m-0 font-weight-bold">
                        <i class="fas fa-signature mr-2"></i> DocuSign Connection
                    </h5>
                    <a href="{{ route('users.index') }}" class="btn btn-sm btn-light">
                        <i class="fas fa-arrow-left"></i> Back
                    </a>
                </div>

                <div class="card-body">
                    <!-- Connection Status Card -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="card border-left-{{ $isConnected ? 'success' : 'danger' }} shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-{{ $isConnected ? 'success' : 'danger' }} text-uppercase mb-1">
                                                Connection Status
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                @if($isConnected)
                                                    <span class="text-success">
                                                        <i class="fas fa-check-circle mr-2"></i>Connected
                                                    </span>
                                                @else
                                                    <span class="text-danger">
                                                        <i class="fas fa-times-circle mr-2"></i>Not Connected
                                                    </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-plug fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="text-center py-4">
                        <div class="mb-4">
                            <i class="fas fa-link fa-3x text-primary mb-3"></i>
                            <h5 class="font-weight-bold">Connect your account with DocuSign</h5>
                            <p class="text-muted">
                                Securely integrate DocuSign to send and manage contracts directly from this dashboard.
                            </p>
                        </div>

                        @if($isConnected)
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle mr-2"></i>
                                Your DocuSign account is successfully connected!
                            </div>
                        @else
                            <a href="{{ route('connect.docusign') }}" class="btn btn-lg btn-warning shadow-sm px-4 py-2">
                                <i class="fas fa-plug mr-2"></i> Connect to DocuSign
                            </a>
                        @endif
                    </div>
                </div>

                <div class="card-footer text-center text-muted small">
                    <i class="fas fa-shield-alt"></i> Your credentials are securely encrypted
                </div>
            </div>
        </div>
    </div>
</div>
@endsection