@extends('admin.layouts.master')
@section('content')
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Payments for {{ $subscription->user->name }} ({{ $subscription->package->name }})</h6>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Txn ID</th>
                            <th>Amount</th>
                            <th>Comment</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                            $paidInstallments = $payments->count();
                            $totalInstallments = $subscription->total_installments ?? 1;
                        @endphp

                        @for($i = 1; $i <= $totalInstallments; $i++)
                            @php
                                $payment = $payments->get($i - 1);
                                $isPending = !$payment;
                                $isLastInstallment = $i === $totalInstallments;
                                $displayDate = '—';

                                if ($payment) {
                                    $displayDate = $payment->created_at->format('d M, Y') . ' (Paid)';
                                } elseif ($isPending) {
                                    if ($isLastInstallment) {
                                        $displayDate = \Carbon\Carbon::parse($subscription->end_date)->format('d M, Y') . ' (End Date)';
                                    } else {
                                        $displayDate = \Carbon\Carbon::parse($subscription->next_due_date)
                                            ->addMonths($i - $paidInstallments - 1)
                                            ->format('d M, Y') . ' (Next Due)';
                                    }
                                }
                            @endphp

                            <tr>
                                <td>{{ $i }}</td>
                                <td>{{ $payment->txn_id ?? '—' }}</td>
                                <td>${{ number_format($payment->amount ?? $subscription->installment_amount, 2) }}</td>
                                <td>{{ $payment->comment ?? '—' }}</td>
                                <td>
                                    @if($payment)
                                        <span class="badge badge-success">PAID</span>
                                    @else
                                        <span class="badge badge-warning">PENDING</span>
                                    @endif
                                </td>
                                <td>{{ $displayDate }}</td>
                            </tr>
                        @endfor
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
