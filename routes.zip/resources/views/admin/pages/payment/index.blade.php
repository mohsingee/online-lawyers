@extends('admin.layouts.master')
@section('content')
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Payment History</h6>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>User</th>
                            <th>Email</th>
                            <th>Package</th>
                            <th>Plan</th>
                            <th>Subscription Type</th>
                            <th>Paid Amount</th>
                            <th>Installment</th>
                            <th>Next Due</th>
                            <th>Status</th>
                            <th>View</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($paymentsGrouped as $key => $subscriptionPayments)
                            @php
                                $sub = $subscriptionPayments->first()->subscription;
                                $totalPaid = $subscriptionPayments->sum('amount');
                                $lastPayment = $subscriptionPayments->first(); // most recent payment
                            @endphp
                            <tr>
                                <td>{{ $key + 1 }}</td>
                                <td>{{ $sub->user->name ?? 'N/A' }}</td>
                                <td>{{ $sub->user->email ?? 'N/A' }}</td>
                                <td>{{ $sub->package->name ?? 'N/A' }}</td>
                                <td>{{ $sub->plan->title ?? 'N/A' }}</td>
                                <td>{{ ucfirst($sub->subscription_type ?? 'N/A') }}</td>
                                <td>${{ number_format($totalPaid, 2) }}</td>
                                <td>{{ $sub->installments_paid ?? 0 }}/{{ $sub->total_installments ?? 0 }}</td>
                                <td>{{ $sub->next_due_date ? \Carbon\Carbon::parse($sub->next_due_date)->format('d M, Y') : '—' }}</td>
                                <td>
                                    @if($sub->status == 'completed')
                                        <span class="badge badge-success">Completed</span>
                                    @elseif($sub->status == 'pending')
                                        <span class="badge badge-warning">Pending</span>
                                    @else
                                        <span class="badge badge-info">Active</span>
                                    @endif
                                </td>
                                <td>
                                    <a href="{{ route('payment.view', $sub->id) }}" class="btn btn-info btn-sm">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

