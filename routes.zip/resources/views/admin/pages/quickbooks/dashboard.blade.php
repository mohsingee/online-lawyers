@extends('admin.layouts.master')
@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-lg border-0 rounded-lg mt-5">
                <div class="card-header bg-gradient-success text-white d-flex justify-content-between align-items-center">
                    <h5 class="m-0 font-weight-bold">
                        <i class="fas fa-book mr-2"></i> QuickBooks Connection
                    </h5>
                    <a href="{{ route('users.index') }}" class="btn btn-sm btn-light">
                        <i class="fas fa-arrow-left"></i> Back
                    </a>
                </div>

                <div class="card-body">
                    <!-- Connection Status -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Connection Status
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                @if($connected)
                                                    <span class="text-success">Connected</span>
                                                @else
                                                    <span class="text-danger">Not Connected</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-plug fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                                QuickBooks Realm ID
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                {{ $realmId ?? 'N/A' }}
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-id-card fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Main Connection Section -->
                    <div class="text-center py-4">
                        <div class="mb-4">
                            <i class="fas fa-calculator fa-3x text-success mb-3"></i>
                            <h5 class="font-weight-bold">Connect your account with QuickBooks</h5>
                            <p class="text-muted">
                                Securely integrate QuickBooks to sync payments, invoices, and customer data directly from this dashboard.
                            </p>
                        </div>

                        @if(!$connected)
                            <a href="{{ route('quickbooks.connect') }}" class="btn btn-lg btn-success shadow-sm px-4 py-2">
                                <i class="fas fa-plug mr-2"></i> Connect to QuickBooks
                            </a>
                        @else
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle mr-2"></i> 
                                Your account is successfully connected to QuickBooks!
                            </div>
                        @endif
                    </div>

                    <!-- Quick Actions (Only show when connected) -->
                    @if($connected)
                    <div class="row mt-4">
                        <div class="col-12">
                            <h6 class="font-weight-bold text-dark mb-3">
                                <i class="fas fa-bolt mr-2"></i> Quick Actions
                            </h6>
                        </div>
                        
                        <!-- Check Customer -->
                        <div class="col-md-4 mb-3">
                            <div class="card border-left-warning shadow h-100">
                                <div class="card-body">
                                    <div class="text-center">
                                        <i class="fas fa-search fa-2x text-warning mb-2"></i>
                                        <h6 class="font-weight-bold text-dark">Check Customer</h6>
                                        <p class="small text-muted">Verify if customer exists by email</p>
                                        <button type="button" class="btn btn-sm btn-outline-warning" data-toggle="modal" data-target="#checkCustomerModal">
                                            Check Now
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Create Customer -->
                        <div class="col-md-4 mb-3">
                            <div class="card border-left-info shadow h-100">
                                <div class="card-body">
                                    <div class="text-center">
                                        <i class="fas fa-user-plus fa-2x text-info mb-2"></i>
                                        <h6 class="font-weight-bold text-dark">Create Customer</h6>
                                        <p class="small text-muted">Add new customer to QuickBooks</p>
                                        <button type="button" class="btn btn-sm btn-outline-info" data-toggle="modal" data-target="#createCustomerModal">
                                            Create New
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Create Payment -->
                        <div class="col-md-4 mb-3">
                            <div class="card border-left-success shadow h-100">
                                <div class="card-body">
                                    <div class="text-center">
                                        <i class="fas fa-credit-card fa-2x text-success mb-2"></i>
                                        <h6 class="font-weight-bold text-dark">Create Payment</h6>
                                        <p class="small text-muted">Sync payment from Elavon</p>
                                        <button type="button" class="btn btn-sm btn-outline-success" data-toggle="modal" data-target="#createPaymentModal">
                                            Sync Payment
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Activity -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="card shadow">
                                <div class="card-header bg-light">
                                    <h6 class="m-0 font-weight-bold text-dark">
                                        <i class="fas fa-history mr-2"></i> Recent Activity
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="text-center text-muted py-3">
                                        <i class="fas fa-clock fa-2x mb-2"></i>
                                        <p>Activity log will appear here</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>

                <div class="card-footer text-center text-muted small">
                    <i class="fas fa-shield-alt"></i> Your QuickBooks credentials are securely encrypted
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Check Customer Modal -->
@if($connected)
<div class="modal fade" id="checkCustomerModal" tabindex="-1" role="dialog" aria-labelledby="checkCustomerModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title" id="checkCustomerModalLabel">
                    <i class="fas fa-search mr-2"></i> Check Customer
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="checkCustomerForm">
                    @csrf
                    <div class="form-group">
                        <label for="customerEmail" class="font-weight-bold">Customer Email</label>
                        <input type="email" class="form-control" id="customerEmail" name="email" required placeholder="Enter customer email address">
                    </div>
                </form>
                <div id="checkCustomerResult" class="mt-3"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-warning" onclick="checkCustomer()">Check Customer</button>
            </div>
        </div>
    </div>
</div>

<!-- Create Customer Modal -->
<div class="modal fade" id="createCustomerModal" tabindex="-1" role="dialog" aria-labelledby="createCustomerModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title" id="createCustomerModalLabel">
                    <i class="fas fa-user-plus mr-2"></i> Create New Customer
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="createCustomerForm">
                    @csrf
                    <div class="form-group">
                        <label for="customerName" class="font-weight-bold">Full Name *</label>
                        <input type="text" class="form-control" id="customerName" name="name" required placeholder="Enter customer full name">
                    </div>
                    <div class="form-group">
                        <label for="customerEmail" class="font-weight-bold">Email Address *</label>
                        <input type="email" class="form-control" id="customerEmail" name="email" required placeholder="Enter customer email">
                    </div>
                    <div class="form-group">
                        <label for="customerCompany" class="font-weight-bold">Company Name</label>
                        <input type="text" class="form-control" id="customerCompany" name="company" placeholder="Enter company name">
                    </div>
                    <div class="form-group">
                        <label for="customerPhone" class="font-weight-bold">Phone Number</label>
                        <input type="text" class="form-control" id="customerPhone" name="phone" placeholder="Enter phone number">
                    </div>
                </form>
                <div id="createCustomerResult" class="mt-3"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-info" onclick="createCustomer()">Create Customer</button>
            </div>
        </div>
    </div>
</div>

<!-- Create Payment Modal -->
<div class="modal fade" id="createPaymentModal" tabindex="-1" role="dialog" aria-labelledby="createPaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title" id="createPaymentModalLabel">
                    <i class="fas fa-credit-card mr-2"></i> Create Payment
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="createPaymentForm">
                    @csrf
                    <div class="form-group">
                        <label for="paymentCustomerEmail" class="font-weight-bold">Customer Email *</label>
                        <input type="email" class="form-control" id="paymentCustomerEmail" name="customer_email" required placeholder="Enter customer email">
                    </div>
                    <div class="form-group">
                        <label for="paymentAmount" class="font-weight-bold">Amount *</label>
                        <input type="number" step="0.01" class="form-control" id="paymentAmount" name="amount" required placeholder="0.00">
                    </div>
                    <div class="form-group">
                        <label for="paymentDate" class="font-weight-bold">Payment Date *</label>
                        <input type="date" class="form-control" id="paymentDate" name="payment_date" required value="{{ date('Y-m-d') }}">
                    </div>
                    <div class="form-group">
                        <label for="referenceNo" class="font-weight-bold">Reference Number *</label>
                        <input type="text" class="form-control" id="referenceNo" name="reference_no" required placeholder="Transaction reference">
                    </div>
                </form>
                <div id="createPaymentResult" class="mt-3"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-success" onclick="createPayment()">Create Payment</button>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for AJAX calls -->
<script>
function checkCustomer() {
    const form = document.getElementById('checkCustomerForm');
    const resultDiv = document.getElementById('checkCustomerResult');
    const email = document.getElementById('customerEmail').value;

    resultDiv.innerHTML = '<div class="text-center"><div class="spinner-border text-warning" role="status"></div><p>Checking...</p></div>';

    fetch('/quickbooks/check-customer', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify({email: email})
    })
    .then(response => response.json())
    .then(data => {
        if (data.exists) {
            resultDiv.innerHTML = `
                <div class="alert alert-success">
                    <i class="fas fa-check-circle mr-2"></i>
                    <strong>Customer Found!</strong><br>
                    Name: ${data.customer.name}<br>
                    Email: ${data.customer.email}<br>
                    Company: ${data.customer.company || 'N/A'}<br>
                    <small class="text-muted">ID: ${data.customer.id}</small>
                </div>
            `;
        } else {
            resultDiv.innerHTML = `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle mr-2"></i>
                    No customer found with this email. You can create a new customer.
                </div>
            `;
        }
    })
    .catch(error => {
        resultDiv.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-times-circle mr-2"></i>
                Error checking customer. Please try again.
            </div>
        `;
    });
}

function createCustomer() {
    const form = document.getElementById('createCustomerForm');
    const resultDiv = document.getElementById('createCustomerResult');
    const formData = new FormData(form);

    resultDiv.innerHTML = '<div class="text-center"><div class="spinner-border text-info" role="status"></div><p>Creating customer...</p></div>';

    fetch('/quickbooks/create-customer', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            resultDiv.innerHTML = `
                <div class="alert alert-success">
                    <i class="fas fa-check-circle mr-2"></i>
                    <strong>Success!</strong> ${data.message}<br>
                    Customer ID: ${data.customer_id}<br>
                    Customer Name: ${data.customer_name}
                </div>
            `;
            form.reset();
        } else {
            resultDiv.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-times-circle mr-2"></i>
                    <strong>Error!</strong> ${data.message}
                    ${data.customer_id ? `<br>Existing Customer ID: ${data.customer_id}` : ''}
                </div>
            `;
        }
    })
    .catch(error => {
        resultDiv.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-times-circle mr-2"></i>
                Error creating customer. Please try again.
            </div>
        `;
    });
}

function createPayment() {
    const form = document.getElementById('createPaymentForm');
    const resultDiv = document.getElementById('createPaymentResult');
    const formData = new FormData(form);

    resultDiv.innerHTML = '<div class="text-center"><div class="spinner-border text-success" role="status"></div><p>Processing payment...</p></div>';

    fetch('/quickbooks/create-payment', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            resultDiv.innerHTML = `
                <div class="alert alert-success">
                    <i class="fas fa-check-circle mr-2"></i>
                    <strong>Success!</strong> ${data.message}<br>
                    Payment ID: ${data.payment_id}<br>
                    Amount: $${data.amount}<br>
                    Customer: ${data.customer_name}
                </div>
            `;
            form.reset();
        } else {
            resultDiv.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-times-circle mr-2"></i>
                    <strong>Error!</strong> ${data.message}
                </div>
            `;
        }
    })
    .catch(error => {
        resultDiv.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-times-circle mr-2"></i>
                Error processing payment. Please try again.
            </div>
        `;
    });
}

// Reset modals when closed
$('.modal').on('hidden.bs.modal', function () {
    $(this).find('form').trigger('reset');
    $(this).find('.alert').remove();
});
</script>
@endif
@endsection