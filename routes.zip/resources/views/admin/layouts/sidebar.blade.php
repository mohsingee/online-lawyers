<!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ route('dashboard') }}">
            <img src="{{asset('assets/mainlogopng.png')}}" alt="" width="110">
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider my-0">

       <!-- Dashboard -->
        <li class="nav-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
            <a class="nav-link" href="{{ route('dashboard') }}">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <hr class="sidebar-divider">

        <div class="sidebar-heading">
            Interface
        </div>

        <!-- DocuSign -->
        <li class="nav-item {{ request()->routeIs('docusign') || request()->routeIs('connect.docusign') ? 'active' : '' }}">
            <a class="nav-link" href="{{ route('docusign') }}">
                <i class="fas fa-fw fa-link"></i>
                <span>DocuSign Connection</span>
            </a>
        </li>

        <!-- QuickBooks -->
        <li class="nav-item {{ request()->routeIs('quickbooks.dashboard') || request()->routeIs('quickbooks.connect') ? 'active' : '' }}">
            <a class="nav-link" href="{{ route('quickbooks.dashboard') }}">
                <i class="fas fa-fw fa-book"></i>
                <span>QuickBooks Connection</span>
            </a>
        </li>

        <!-- Users -->
        <li class="nav-item {{ request()->routeIs('users.*') || request()->routeIs('package.choose') ? 'active' : '' }}">
            <a class="nav-link" href="{{ route('users.index') }}">
                <i class="fas fa-fw fa-users"></i>
                <span>My Users</span>
            </a>
        </li>

        <!-- Contracts -->
        <li class="nav-item {{ request()->routeIs('package.assigned') ? 'active' : '' }}">
            <a class="nav-link" href="{{ route('package.assigned') }}">
                <i class="fas fa-fw fa-file-contract"></i>
                <span>Assigned Contracts</span>
            </a>
        </li>

        <li class="nav-item {{ request()->routeIs('payment.history') ? 'active' : '' }}">
            <a class="nav-link" href="{{ route('payment.history') }}">
                <i class="fas fa-money-check-alt"></i>
                <span>Payment History</span>
            </a>
        </li>
    </ul>
<!-- End of Sidebar -->