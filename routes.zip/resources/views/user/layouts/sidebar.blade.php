<!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ route('dashboard') }}">
            <img src="{{asset('assets/mainlogopng.png')}}" alt="" width="110">
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider my-0">

        <!-- Nav Item - Dashboard -->
        <li class="nav-item active">
            <a class="nav-link" href="{{ route('dashboard') }}">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span></a>
        </li>

        <!-- Divider -->
        <hr class="sidebar-divider">

        <!-- Heading -->
        <div class="sidebar-heading">
            Interface
        </div>

        <li class="nav-item active">
            <a class="nav-link" href="{{ route('user.contracts') }}">
                <i class="fas fa-file-signature"></i> <!-- better icon for signing -->
                <span>Sign Contract</span>
            </a>
        </li>

        <li class="nav-item active">
            <a class="nav-link" href="{{ route('payment.index') }}">
                <i class="fas fa-dollar-sign"></i> <!-- better icon for signing -->
                <span>My Payments</span>
            </a>
        </li>
    </ul>
<!-- End of Sidebar -->