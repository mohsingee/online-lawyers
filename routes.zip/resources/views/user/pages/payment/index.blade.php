@extends('user.layouts.master')

@section('content')
<div class="container mt-5">
    <div class="card shadow-lg border-0 rounded-4">
        <div class="card-header bg-gradient-to-r from-primary to-indigo-600 py-3 rounded-top-4">
            <h4 class="mb-0"><i class="fas fa-wallet me-2"></i> Manage Your Subscription</h4>
        </div>

        <div class="card-body">
            <h5 class="fw-bold mb-1">Welcome, {{ $user->name }} 👋</h5>
            <p class="text-muted mb-4">
                Here you can view your active subscription, check your payment plan, and make payments when due.
            </p>

            {{-- ✅ Subscription Section --}}
            @if(isset($subscription))
                <div class="bg-light rounded-4 p-4 border position-relative overflow-hidden mb-4">
                    <div class="d-flex align-items-center mb-3">
                        <div>
                            <h5 class="fw-bold mb-0 text-primary">{{ $subscription->package->name ?? 'Selected Package' }}</h5>
                            <small class="text-muted">Your current active plan</small>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <strong>Total Amount:</strong>
                            <div class="text-dark">${{ number_format($subscription->total_amount, 2) }}</div>
                        </div>

                        <div class="col-md-4 mb-3">
                            <strong>Plan Type:</strong>
                            <div>
                                <span class="badge text-white bg-{{ $subscription->subscription_type === 'full' ? 'success' : 'info' }}">
                                    {{ ucfirst($subscription->subscription_type) }}
                                </span>
                            </div>
                        </div>

                        @if($subscription->subscription_type === 'installment')
                            <div class="col-md-4 mb-3">
                                <strong>Total Installments:</strong>
                                <div>{{ $subscription->total_installments }}</div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <strong>Installments Paid:</strong>
                                <div>{{ $subscription->installments_paid }}</div>
                            </div>
                        @endif

                        <div class="col-md-4 mb-3">
                            <strong>Status:</strong>
                            <div>
                                <span class="badge text-white bg-{{ $subscription->status === 'completed' ? 'success' : ($subscription->status === 'active' ? 'primary' : 'warning') }}">
                                    {{ ucfirst($subscription->status) }}
                                </span>
                            </div>
                        </div>

                        <div class="col-md-4 mb-3">
                            <strong>Start Date:</strong>
                            <div>{{ \Carbon\Carbon::parse($subscription->start_date)->format('d M, Y') }}</div>
                        </div>
                    </div>
                </div>

                {{-- ✅ Completed --}}
                @if($subscription->status === 'completed')
                    <div class="alert alert-success mt-4">
                        <i class="fas fa-check-circle me-2"></i>
                        You’ve completed all your payments. Thank you for staying with us!
                    </div>

                {{-- 💳 Full Payment Plan --}}
                @elseif($subscription->subscription_type === 'full' && !$subscription->next_due_date)
                    <div class="alert alert-warning mt-4">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        Your full payment is pending. Please complete it to activate your subscription.
                    </div>

                    <div class="text-center mt-3">
                        <form action="{{ route('payment.process', $subscription->id) }}" method="POST">
                            @csrf
                            <button type="submit" class="btn btn-success btn-lg rounded-pill px-5 shadow-sm">
                                <i class="fas fa-credit-card me-2"></i>
                                Pay Full Amount – ${{ number_format($subscription->total_amount, 2) }}
                            </button>
                        </form>
                    </div>

                {{-- 🟡 Installment Plan - First Payment Pending --}}
                @elseif($subscription->subscription_type === 'installment' && $subscription->installments_paid == 0)
                    <div class="alert alert-warning mt-4">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        You haven’t made your first payment yet. Start your subscription by paying the first installment.
                    </div>

                    <div class="text-center mt-3">
                        <form action="{{ route('payment.installment', $subscription->id) }}" method="POST">
                            @csrf
                            <button type="submit" class="btn btn-primary btn-lg rounded-pill px-5 shadow-sm">
                                <i class="fas fa-credit-card me-2"></i>
                                Start Subscription – Pay ${{ number_format($subscription->installment_amount, 2) }}
                            </button>
                        </form>
                    </div>

                {{-- 📅 Installment Plan - Ongoing --}}
                @elseif($subscription->subscription_type === 'installment' && $subscription->installments_paid > 0 && $subscription->status !== 'completed')
                    <div class="alert alert-info mt-4">
                        <i class="fas fa-calendar-alt me-2"></i>
                        <strong>Next Payment Due:</strong>
                        {{ \Carbon\Carbon::parse($subscription->next_due_date)->format('d M, Y') }} — 
                        <strong>Amount:</strong> ${{ number_format($subscription->installment_amount, 2) }}
                    </div>

                    <div class="text-center mt-3">
                        <small class="text-muted">
                            Your next payment will be processed automatically on the due date.
                        </small>
                    </div>
                @endif

            @else
                {{-- ❌ No Active Subscription --}}
                <div class="alert alert-secondary mt-4">
                    <i class="fas fa-info-circle me-2"></i>
                    No active subscription found. Please select a package to get started.
                </div>
            @endif

            {{-- 📜 Payment History (Visible Only if Paid At Least One) --}}
            @if(isset($subscription) && $subscription->installments_paid > 0)
                <hr class="my-5">
                <h5 class="fw-bold mb-3">
                    <i class="fas fa-list me-2 text-primary"></i> Payment History
                </h5>

                <div class="table-responsive">
                    <table class="table table-bordered align-middle">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Txn ID</th>
                                <th>Amount</th>
                                <th>Comment</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                                $paidInstallments = $payments->count();
                                $totalInstallments = $subscription->total_installments ?? 1;
                            @endphp

                            @for($i = 1; $i <= $totalInstallments; $i++)
                                @php
                                    $payment = $payments->get($i - 1);
                                    $isPending = !$payment;
                                    $isLastInstallment = $i === $totalInstallments;
                                    $displayDate = '—';

                                    if ($payment) {
                                        $displayDate = $payment->created_at->format('d M, Y') . ' (Paid)';
                                    } elseif ($isPending) {
                                        if ($isLastInstallment) {
                                            $displayDate = \Carbon\Carbon::parse($subscription->end_date)->format('d M, Y') . ' (End Date)';
                                        } else {
                                            $displayDate = \Carbon\Carbon::parse($subscription->next_due_date)
                                                ->addMonths($i - $paidInstallments - 1)
                                                ->format('d M, Y') . ' (Next Due)';
                                        }
                                    }
                                @endphp

                                <tr>
                                    <td>{{ $i }}</td>
                                    <td>{{ $payment->txn_id ?? '—' }}</td>
                                    <td>${{ number_format($payment->amount ?? $subscription->installment_amount, 2) }}</td>
                                    <td>{{ $payment->comment ?? '—' }}</td>
                                    <td>
                                        @if($payment)
                                            <span class="badge badge-success">PAID</span>
                                        @else
                                            <span class="badge badge-warning">PENDING</span>
                                        @endif
                                    </td>
                                    <td>{{ $displayDate }}</td>
                                </tr>
                            @endfor
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection
