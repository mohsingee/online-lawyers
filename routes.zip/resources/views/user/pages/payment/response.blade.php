@extends('user.layouts.master')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            
            <div class="card shadow-lg border-0 rounded-4">
                <div class="card-header text-center py-4 
                    @if($status == 'success') bg-success text-white 
                    @elseif($status == 'error') bg-danger text-white 
                    @else bg-secondary text-white @endif">
                    <h4 class="mb-0">
                        @if($status == 'success')
                            <i class="bi bi-check-circle me-2"></i> {{$message}}
                        @elseif($status == 'error')
                            <i class="bi bi-x-circle me-2"></i> {{$message}}
                        @else
                            <i class="bi bi-info-circle me-2"></i> {{$message}}
                        @endif
                    </h4>
                </div>

                <div class="card-body text-center p-4">
                    @if(isset($data['ssl_result_message']))
                        <div class="mb-4">
                            <h5 class="fw-bold text-dark">{{ $data['ssl_result_message'] }}</h5>
                            <p class="text-muted mb-0">Thank you for using our service.</p>
                        </div>

                        <hr class="my-4">

                        <div class="text-start px-3">
                            <p><strong>💰 Amount:</strong> {{ $data['ssl_amount'] ?? 'N/A' }}</p>
                            <p><strong>🧾 Invoice:</strong> {{ $data['ssl_invoice_number'] ?? 'N/A' }}</p>
                            <p><strong>🔢 Transaction ID:</strong> {{ $data['ssl_txn_id'] ?? 'N/A' }}</p>
                            <p><strong>⏱ Date:</strong> {{ now()->format('d M Y, h:i A') }}</p>
                        </div>
                    @else
                        <div class="text-center">
                            <p class="text-muted">⚠️ No payment response data received.</p>
                        </div>
                    @endif
                </div>

                <div class="card-footer text-center bg-light py-3">
                    <a href="{{ route('payment.index') }}" class="btn btn-primary px-4">
                        <i class="bi bi-arrow-left-circle me-2"></i> Back to Payments
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>
@endsection
