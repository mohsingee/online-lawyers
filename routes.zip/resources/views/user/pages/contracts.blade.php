@extends('user.layouts.master')

@section('content')
<div class="container d-flex justify-content-center mt-5">
    <div class="card shadow-lg p-4" style="max-width: 800px; width:100%; min-height: 500px;">

        @if(isset($signedContract))
        <div class="signed-card text-center p-4">
            <div class="checkmark-wrapper mb-4">
                <div class="checkmark-circle">
                    <i class="bi bi-check-lg text-white"></i>
                </div>
            </div>

            <h3 class="fw-bold text-success mb-3">Agreement Signed Successfully!</h3>
            <p class="text-muted mb-4">Thank you! Your digital signature has been recorded securely.</p>

            <div class="signed-info-card mx-auto text-start p-4 shadow-sm">
                <h5 class="border-bottom pb-2 mb-3 text-dark fw-semibold">
                    <i class="bi bi-file-earmark-text me-2 text-success"></i> Contract Summary
                </h5>
                <p class="mb-2"><strong>📦 Package:</strong> <span class="text-secondary">{{ $signedContract->plan->package->name ?? 'N/A' }}</span></p>
                <p class="mb-2"><strong>💳 Selected Plan:</strong> <span class="text-secondary">{{ $signedContract->plan->description ?? 'N/A' }}</span></p>
                <p class="mb-2"><strong>🟢 Status:</strong> <span class="badge bg-success text-white px-3 py-2">Signed</span></p>
                <p class="mb-0"><strong>🗓️ Signed On:</strong> <span class="text-secondary">{{ \Carbon\Carbon::parse($signedContract->signed_at)->format('d M Y') }}</span></p>
            </div>

            <div class="mt-4">
                <a href="{{ route('payment.index') }}" class="btn btn-outline-success px-4 rounded-pill shadow-sm">
                    <i class="bi bi-house-door me-2"></i>Go to Payments
                </a>
            </div>
        </div>

        @elseif($contracts)
            {{-- ✅ Package Selection Display --}}
            <h3 class="mb-4 text-center">Please Select the Package</h3>

            <!-- Package Buttons -->
            <div class="d-flex flex-wrap justify-content-center mb-4">
                @foreach($contracts as $contract)
                    <button type="button" class="btn btn-outline-primary m-2 contract-btn shadow-sm" data-id="{{ $contract->id }}">
                        {{ $contract->package->name ?? 'Unnamed Package' }}
                    </button>
                @endforeach
            </div>

            <h5 id="plansTitle" class="mt-3 text-center" style="display:none;">Available Plans</h5>
            <div id="optionsContainer" class="d-flex flex-column align-items-center"></div>

            <!-- Sign Agreement Button -->
            <div class="text-center mt-3" id="signButtonContainer" style="display:none;">
                <form id="signForm" method="POST" action="{{ route('user.signAgreement') }}">
                    @csrf
                    <input type="hidden" name="plan_id" id="selectedPlanId">
                    <button type="submit" id="signBtn" class="btn btn-success btn-lg shadow-sm">
                        <span class="btn-text">Click to Sign the Agreement</span>
                        <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                    </button>
                </form>
            </div>

        @else
            <div class="alert alert-warning mt-3 text-center">
                {{ $message }}
            </div>
        @endif

    </div>
</div>
@endsection

@section('js')
<script>
$(document).ready(function() {
    var contracts = @json($contracts);

    $('.contract-btn').on('click', function() {
        var contractId = $(this).data('id');
        var selectedContract = contracts.find(c => c.id == contractId);

        // Highlight selected package button
        $('.contract-btn').removeClass('btn-primary').addClass('btn-outline-primary');
        $(this).removeClass('btn-outline-primary').addClass('btn-primary');

        if(selectedContract) {
            var html = '';
            $.each(selectedContract.package.plans, function(i, plan) {
                html += `
                    <div class="w-100 mb-3">
                        <label class="btn btn-outline-info plan-btn shadow-sm p-3 d-flex flex-column align-items-start">
                            <input type="radio" name="package_option" value="${plan.id}" class="d-none">
                            <strong>${plan.description}</strong>
                        </label>
                    </div>
                `;
            });

            $('#plansTitle').fadeIn();
            $('#optionsContainer').html(html);
            $('#signButtonContainer').hide();
        }
    });

    // Toggle plan selection
    $(document).on('click', '.plan-btn', function() {
        $('.plan-btn').removeClass('btn-info').addClass('btn-outline-info');
        $(this).removeClass('btn-outline-info').addClass('btn-info');
        var selectedPlanId = $(this).find('input[type=radio]').val();
        $(this).find('input[type=radio]').prop('checked', true);

        $('#selectedPlanId').val(selectedPlanId);
        $('#signButtonContainer').fadeIn();
    });

    // Disable button + show loader
    $('#signForm').on('submit', function(e) {
        var btn = $('#signBtn');
        btn.prop('disabled', true);
        btn.find('.btn-text').text('Processing...');
        btn.find('.spinner-border').removeClass('d-none');
    });
});
</script>
@endsection

@section('css')
<style>
.card {
    border-radius: 15px;
    overflow-y: auto;
}
.contract-btn {
    min-width: 180px;
    padding: 15px 20px;
    font-size: 16px;
    transition: transform 0.2s, box-shadow 0.2s;
}
.contract-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 15px rgba(0,0,0,0.15);
}
.plan-btn {
    width: 100%;
    padding: 20px 25px;
    font-size: 15px;
    cursor: pointer;
    transition: transform 0.2s, box-shadow 0.2s;
    border-radius: 10px;
    text-align: left;
}
.plan-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 15px rgba(0,0,0,0.15);
}
#signBtn .spinner-border {
    margin-left: 8px;
    vertical-align: middle;
}
</style>
@endsection
