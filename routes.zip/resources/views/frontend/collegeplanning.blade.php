@extends('frontend.layouts.master')
@section('content')
<!-- hero section  -->
    <section class="hero-section ">
      <div class="container  ">
        <h1 data-aos="fade-up" data-aos-duration="800">College <span class="orange-text">Planning</span></h1>
        <p class="mb-0" data-aos="fade-up" data-aos-delay="200" data-aos-duration="800">
          Comprehensive packages designed to guide you through every step of the
          college application process
        </p>
      </div>
    </section>

    <!-- College Planning Packages Section -->
    <section class="py-6 py-lg-8 background-light" id="packages" style="padding-top: 4rem !important; padding-bottom: 4rem !important;">
      <div class="container">
 
        <div class="text-center mb-5" data-aos="fade-up" style="margin-bottom: 3rem !important;">
          <h2 class="display-6 text-primary-orange fw-bold" data-aos="fade-up" data-aos-delay="100">
            College Planning Packages
          </h2>
          <p>
            Find the right support for your unique college application journey.
          </p>
        </div>

        <div
          class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 d-flex align-items-stretch"
        >
          <div class="col d-flex" data-aos="fade-up" data-aos-delay="100">
            <div class="card border-2 shadow-sm hover-shadow-lg enhanced-card h-100">
              <div class="card-body d-flex flex-column">
                <div
                  class="p-3 mx-auto mb-4 rounded-circle d-flex align-items-center justify-content-center bg-primary-orange"
                  style="width: 64px; height: 64px"
                >
                  <i class="bi bi-people-fill text-white fs-3"></i>
                </div>

                <h3 class="fs-4 mb-3 text-center flex-grow-1">
                  College Planning Intensive
                </h3>
                <p class="text-muted mb-4 text-center flex-grow-1 d-none">
                  Eight weekend classroom sessions where you learn proven
                  strategies and methods of demystifying the entire college
                  application process.
                </p>

                <div class="content-wrapper show">
                  <ul class="list-unstyled session-list mb-4">
                    <li class="session-item">
                      <div class="session-icon">
                        <i class="bi bi-calendar-event text-primary-orange"></i>
                      </div>
                      <div class="session-details">
                        <div class="session-title">First Session</div>
                        <div class="session-date">January 13 - March 2nd</div>
                      </div>
                    </li>
                    <li class="session-item fade-in" data-delay="200">
                      <div class="session-icon">
                        <i class="bi bi-calendar-event text-primary-orange"></i>
                      </div>
                      <div class="session-details">
                        <div class="session-title">Second Session</div>
                        <div class="session-date">March 9th - April 27th</div>
                      </div>
                    </li>
                    <li class="session-item fade-in" data-delay="300">
                      <div class="session-icon">
                        <i class="bi bi-calendar-event text-primary-orange"></i>
                      </div>
                      <div class="session-details">
                        <div class="session-title">Third Session</div>
                        <div class="session-date">May 4th - June 22nd</div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <div class="col d-flex" data-aos="fade-up" data-aos-delay="200">
            <div class="card border-2 shadow-lg enhanced-card card-featured h-100">
              <div class="card-body text-center d-flex flex-column">
                <span
                  class="badge bg-primary-orange mx-auto mb-3 px-3 py-2 rounded-pill fw-bold"
                  >Most Popular</span
                >
                <div
                  class="p-3 mx-auto mb-4 rounded-circle d-flex align-items-center justify-content-center bg-primary-orange"
                  style="width: 64px; height: 64px"
                >
                  <i class="bi bi-file-text-fill text-white fs-3"></i>
                </div>
                <h3 class="fs-4 mb-2">
                  Comprehensive College Application Package
                </h3>
                <p class="text-muted flex-grow-1 d-none">
                  Complete end-to-end support for your college application
                  journey
                </p>

                <div class="content-wrapper collapse" id="content-package-2">
                  <div class="pt-3 text-start small">
                    <ul class="list-unstyled mb-0 session-list">
                      <li>
                        <i
                          class="bi bi-check-circle-fill text-primary-orange me-2"
                        ></i
                        >Comprehensive assistance in completing your Common
                        Application and/or any institutional application.
                      </li>
                      <li>
                        <i
                          class="bi bi-check-circle-fill text-primary-orange me-2"
                        ></i>
                        Prepared college list to match both your academic and
                        financial profile based on our online college fit
                        assessment.
                      </li>
                      <li>
                        <i
                          class="bi bi-check-circle-fill text-primary-orange me-2"
                        ></i>
                        Expert assistance in crafting your personal statement
                        and supplemental essays to best reflect your unique
                        experience for up to 12 schools.
                      </li>
                      <li>
                        <i
                          class="bi bi-check-circle-fill text-primary-orange me-2"
                        ></i>
                        Online College Planning Portal
                      </li>
                      <li>
                        <i
                          class="bi bi-check-circle-fill text-primary-orange me-2"
                        ></i>
                        Student Resume
                      </li>
                      <div class="collapse-details">
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          FAFSA Preparation and Processing
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i
                          >CSS Profile Preparation
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          Institutional / Verification Forms
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          College / Parent Plus Loan Assistance
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          Custodial / Non-Custodial Forms
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          IDOC Documents
                        </li>
                      </div>
                    </ul>
                  </div>
                </div>
                <a
                  class="collapse-toggle-btn mt-auto"
                  data-bs-toggle="collapse"
                  href="#content-package-2"
                  role="button"
                  aria-expanded="false"
                  aria-controls="content-package-2"
                >
                  <span class="see-more-text">See Full Details...</span>
                  <span class="see-less-text" style="display: none"
                    >See Less</span
                  >
                </a>
              </div>
            </div>
          </div>

          <div class="col d-flex" data-aos="fade-up" data-aos-delay="300">
            <div class="card enhanced-card h-100 border-2 shadow-sm hover-shadow-lg">
              <div class="card-body text-center d-flex flex-column">
                <div
                  class="p-3 mx-auto mb-4 rounded-circle d-flex align-items-center justify-content-center bg-primary-orange"
                  style="width: 64px; height: 64px"
                >
                  <i class="bi bi-currency-dollar text-white fs-3"></i>
                </div>
                <h3 class="fs-4 mb-2">Financial Aid Only Package</h3>
                <p class="text-muted flex-grow-1 d-none">
                  Specialized support focused exclusively on maximizing your
                  financial aid opportunities
                </p>

                <div class="content-wrapper collapse" id="content-package-3">
                  <div class="pt-3 text-start small">
                    <ul class="list-unstyled mb-0 session-list">
                      <li>
                        <i
                          class="bi bi-check-circle-fill text-primary-orange me-2"
                        ></i>
                        FAFSA Preparation and Processing
                      </li>
                      <li>
                        <i
                          class="bi bi-check-circle-fill text-primary-orange me-2"
                        ></i>
                        CSS Profile Preparation and Processing
                      </li>
                      <li>
                        <i
                          class="bi bi-check-circle-fill text-primary-orange me-2"
                        ></i>
                        Institutional / Verification Forms
                      </li>
                      <div class="collapse-details">
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          College / Parent Plus Loan Assistance
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          Custodial / Non-Custodial Forms
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          IDOC Documents
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          Custom Financial Aid Timeline
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          Expected Family Contribution Review and Analysis
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          Estimated Need-Based Award by School
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          Comprehensive Award Letter Review
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          Direct Appeals Initiation
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          Professional Judgment Letters
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          Student Loan Counseling
                        </li>
                        <li>
                          <i
                            class="bi bi-check-circle-fill text-primary-orange me-2"
                          ></i>
                          College Cost Comparison
                        </li>
                      </div>
                    </ul>
                  </div>
                </div>

                <a
                  class="collapse-toggle-btn mt-auto"
                  data-bs-toggle="collapse"
                  href="#content-package-3"
                  role="button"
                  aria-expanded="false"
                  aria-controls="content-package-3"
                >
                  <span class="see-more-text">See Full Details...</span>
                  <span class="see-less-text" style="display: none"
                    >See Less</span
                  >
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Why Choose Us Section -->
    <section class="py-6 py-lg-8 bg-white" style="padding-top: 4rem !important; padding-bottom: 4rem !important;">
      <div class="container text-center mb-5" style="max-width: 900px; margin-bottom: 3rem !important;" data-aos="fade-up">
        <h2 class=" text-primary-orange mb-4" data-aos="fade-up" data-aos-delay="100">
          Why Choose Our College Planning Services?
        </h2>
        <div class="row g-4">
          <div class="col-12 col-md-4" data-aos="fade-up" data-aos-delay="100">
            <div
              class="p-3 mx-auto mb-3 rounded-circle d-flex align-items-center justify-content-center bg-primary-orange"
              style="width: 64px; height: 64px"
              data-aos="zoom-in"
              data-aos-delay="200"
            >
              <i class="bi bi-people-fill text-white fs-3"></i>
            </div>
            <h3 class="fs-5 mb-2">Personalized Approach</h3>
            <p class="text-muted">
              Tailored strategies based on your unique academic profile and
              goals
            </p>
          </div>
          <div class="col-12 col-md-4">
            <div
              class="p-3 mx-auto mb-3 rounded-circle d-flex align-items-center justify-content-center bg-primary-orange"
              style="width: 64px; height: 64px"
            >
              <i class="bi bi-check-circle-fill text-white fs-3"></i>
            </div>
            <h3 class="fs-5 mb-2">Proven Results</h3>
            <p class="text-muted">
              95% of our students get accepted to one of their top 3 school
              choices
            </p>
          </div>
          <div class="col-12 col-md-4">
            <div
              class="p-3 mx-auto mb-3 rounded-circle d-flex align-items-center justify-content-center bg-primary-orange"
              style="width: 64px; height: 64px"
            >
              <i class="bi bi-clock-fill text-white fs-3"></i>
            </div>
            <h3 class="fs-5 mb-2">Comprehensive Support</h3>
            <p class="text-muted">
              From test prep to financial aid, we're with you every step of the
              way
            </p>
          </div>
        </div>
      </div>
    </section>
     <!-- Call to Action Section -->
     <section class="contact-section text-center" data-aos="fade-up">
      <div class="container">
          <h2 class="orange-text" style="font-size: 1.875rem; font-weight: 700; margin-bottom: 1.5rem;">Need Help
              Scheduling?</h2>
          <p style="font-size: 1.125rem; color: var(--gray-700); margin-bottom: 2rem;">
              If you have any questions or need assistance, don't hesitate to contact us directly.
          </p>
          <div class="contact-buttons">
              <a href="tel:4248002248" class="contact-button">
                  <svg class="lucide-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path
                          d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-4.71-4.71A19.79 19.79 0 0 1 2 4.18 2 2 0 0 1 4.18 2h3a2 2 0 0 1 2 2.18 15.28 15.28 0 0 0 .79 4.45 2 2 0 0 1-1.25 2.12c-.17.1-.34.2-.5.31A19.53 19.53 0 0 0 10 16.5a19.53 19.53 0 0 0 4.16-2.58c.11-.16.21-.33.31-.5a2 2 0 0 1 2.12-1.25z" />
                  </svg>
                  Call (424) 800-2248
              </a>
              <a href="#" class="contact-button">
                  <svg class="lucide-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                      stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <rect width="20" height="16" x="2" y="4" rx="2" />
                      <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                  </svg>
                  Email Us
              </a>
          </div>
      </div>
  </section>
@endsection
