<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>College Connect</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous" />
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css" />
    <link rel="stylesheet" href="{{asset('assets/frontend/style.css')}}" />
    <link rel="stylesheet" href="{{asset('assets/frontend/css/animations.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="{{asset('assets/frontend/script.js') }}"></script>
    <style>
        /* --- Header Styles --- */
        #main-header {
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            background-color: #fff;
            transition: all 0.3s ease-in-out;
            padding-top: 0;
            padding-bottom: 0;
        }

        #main-header.scrolled {
            background-color: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(5px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        #top-contact-bar {
            transition: all 0.3s ease-in-out;

        }

        #main-header.scrolled #top-contact-bar {
            display: none;
        }

        #top-contact-bar.scrolled {
            padding-top: 0.25rem !important;
            padding-bottom: 0.25rem !important;
            font-size: 0.875rem;
        }
        .navbar-brand {
            padding: 5px 0;
            margin-right: 2rem;
        }

        /* * Logo Styling */
        .navbar-brand .logo-image {
            height: auto;
            max-height: 90px;
            width: auto;
            max-width: 200px;
            object-fit: contain;
            transition: all 0.3s ease;
        }

        @media (max-width: 991.98px) {
            .navbar-brand {
                margin-right: 0;
            }
            .navbar-brand .logo-image {
                height: 60px;
            }
        }

        /* Scrolled state */
        #main-header.scrolled .logo-image {
            max-height: 50px;
            transition: height 0.3s ease;
        }

        .nav-link.nav-btn {
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            transition: all 0.2s;
            color: var(--gray-700);
            font-weight: 500;
        }

        .nav-link.nav-btn:hover,
        .nav-link.nav-btn.active {
            background-color: var(--primary-orange);
            color: white;
        }

        /* Toggler Icon Styling */
        .navbar-toggler {
            border: none;
            font-size: 1.5rem;
            color: black !important;
            background-color: transparent !important;
            transition: color 0.3s;
            background: none;
            padding: 0;
        }

        .navbar-toggler:focus {
            box-shadow: none;
        }

        .navbar-toggler .icon-close {
            display: none;
        }

        /* Off-canvas Menu Styles */
        .offcanvas.offcanvas-bottom {
            height: auto;
            max-height: 80vh;
            border-top-left-radius: 1rem;
            border-top-right-radius: 1rem;
        }

        .offcanvas-handle {
            width: 3rem;
            height: 0.25rem;
            background-color: #ccc;
            border-radius: 9999px;
            margin-bottom: 1.5rem;
        }

        .offcanvas-body .btn {
            font-weight: 500;
        }

        .offcanvas-body .btn.active {
            background-color: #e18552;
            color: white !important;
        }

        @media (min-width: 1024px) {
            .container {
                padding-left: 0 !important;
                padding-right: 0 !important;
            }
        }
    </style>
    @stack('css')
</head>

<body>
    @include('frontend.layouts.header')
    @yield('content')
    @include('frontend.layouts.footer')
</body>
</html>