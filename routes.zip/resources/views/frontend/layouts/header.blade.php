  <!-- Header Component -->
  <header id="main-header" class="fixed-top">
    <div id="top-contact-bar" class="bg-light border-bottom d-none d-lg-block py-1">
      <div class="container">
        <div class="d-flex justify-content-between align-items-center">
          <div class="d-flex align-items-center gap-4 text-secondary small">
            <div class="d-flex align-items-center gap-2">
              <i class="bi bi-envelope"></i>
              <a href="mailto:info@collegeconnect101.com" class="text-decoration-none text-secondary">
                info@collegeconnect101.com
              </a>
            </div>
            <div class="d-flex align-items-center gap-2">
              <i class="bi bi-telephone"></i>
             <a href="tel:424-800-2248" class="text-decoration-none text-secondary">(424) 800-2248</a>
            </div>
          </div>
          <div class="d-flex gap-2">
            <a href="{{route('login')}}" class="btn text-white px-5 btn-sm" style="background-color: var(--primary-orange);">Sign In</a>
          </div>
        </div>
      </div>
    </div>

    <nav class="navbar navbar-expand-lg py-0">
      <div class="container">
        <a class="navbar-brand" href="{{route('home')}}">
          <img src="{{asset('assets/mainlogo.jpeg')}}" alt="College Connect 101" class="logo-image">
        </a>

        <!-- Toggler button with both icons -->
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobile-menu-overlay"
          aria-controls="mobile-menu-overlay">
          <i class="bi bi-list icon-open"></i>
          <i class="bi bi-x icon-close"></i>
        </button>

        <div class="collapse navbar-collapse">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0 gap-2">
            <li class="nav-item"><a class="nav-link nav-btn" href="{{route('home')}}">Home</a></li>
            <li class="nav-item"><a class="nav-link nav-btn" href="{{route('founder')}}">Our Founder</a></li>
            <li class="nav-item"><a class="nav-link nav-btn" href="{{route('collegeplanning')}}">College
                Planning</a></li>
            <li class="nav-item"><a class="nav-link nav-btn" href="{{route('ouracceptence')}}">Our Acceptances</a>
            </li>
            <li class="nav-item"><a class="nav-link nav-btn" href="{{route('contactus')}}">Contact</a></li>
            <li class="nav-item"><a class="nav-link nav-btn" href="{{route('appointement')}}">Make
                Appointment</a></li>
          </ul>
        </div>
      </div>
    </nav>
  </header>

  <div class="offcanvas offcanvas-bottom d-lg-none" tabindex="-1" id="mobile-menu-overlay">
    <div class="offcanvas-header justify-content-center pt-4">
      <div class="offcanvas-handle"></div>
      <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <nav class="d-flex flex-column gap-1">
        <a href="{{route('home')}}" class="btn btn-lg text-start">Home</a>
        <a href="{{route('founder')}}" class="btn btn-lg text-start">Our Founder</a>
        <a href="{{route('collegeplanning')}}" class="btn btn-lg text-start">College Planning</a>
        <a href="{{route('ouracceptence')}}" class="btn btn-lg text-start">Our Acceptances</a>
        <a href="{{route('contactus')}}" class="btn btn-lg text-start">Contact</a>
        <a href="{{route('appointement')}}" class="btn btn-lg text-start ">Make Appointment</a>
      </nav>
      <div class="mt-4 pt-4 border-top d-flex gap-3">
        <a href="{{route('login')}}" class="btn text-white px-5 btn-sm" style="background-color: var(--primary-orange);">Sign In</a>        
      </div>
    </div>
  </div>
  <!-- end header -->