  <!-- footer  -->
  <footer class="pt-5 pb-3">
    <div class="container">
      <!-- Top Grid -->
      <div class="row g-4 mb-5">
        <!-- Address -->
        <div class="col-12 col-md-6 col-lg-3">
          <h3 class="footer-title h5">Address</h3>
          <div class="d-flex">
            <i class="bi bi-geo-alt text-secondary me-2 fs-5"></i>
            <div>
              <p class="mb-0">1626 Centinela Avenue, Suite 202</p>
              <p class="mb-0">Inglewood, CA. 90302</p>
            </div>
          </div>
        </div>

        <!-- Email -->
        <div class="col-12 col-md-6 col-lg-3">
          <h3 class="footer-title h5">Email</h3>
          <div class="d-flex align-items-center footer-link">
            <i class="bi bi-envelope text-secondary me-2 fs-5"></i>
            <a href="mailto:info@collegeconnect101.com">
              info@collegeconnect101.com
            </a>
          </div>
        </div>

        <!-- Phone -->
        <div class="col-12 col-md-6 col-lg-3">
          <h3 class="footer-title h5">Phone</h3>
          <div class="d-flex align-items-center footer-link">
            <i class="bi bi-telephone text-secondary me-2 fs-5"></i>
            <a href="tel:424-800-2248">(424) 800-2248</a>
          </div>
        </div>

        <!-- Appointment -->
        <div class="col-12 col-md-6 col-lg-3">
          <h3 class="footer-title h5">Get on the Calendar!</h3>
          <a href="{{route('appointement')}}" class="text-decoration-none">
            <button class="btn btn-orange w-100 d-flex align-items-center justify-content-center">
              <i class="bi bi-calendar-event me-2"></i>
              Set Appointment Here
            </button>
          </a>
        </div>
      </div>

      <!-- Certifications -->
      <div class="text-center mb-5">
        <h3 class="footer-title h4 mb-4">
          Professional Certifications & Memberships
        </h3>
        <div class="row g-4 justify-content-center">
          <div class="col-12 col-sm-6 col-md-4">
            <!-- <div class="shadow-sm p-3 mb-3 bg-white rounded"> -->
            <img src="{{asset('assets/frontend/assets/footer/WBENC.png') }}" alt="WBENC Certification" class="footer-cert rounded" />
            <!-- </div> -->
            <p class="small text-light">
              Women's Business Enterprise National Council
            </p>
          </div>

          <div class="col-12 col-sm-6 col-md-4">
            <!-- <div class="shadow-sm p-3 mb-3 bg-white rounded"> -->
            <img src="{{asset('assets/frontend/assets/footer/WOSB-SBA.jpg') }}" alt="SBA WOSB Certification" class="footer-cert rounded" />
            <!-- </div> -->
            <p class="small text-light">
              SBA Woman Owned Small Business Certified
            </p>
          </div>

          <div class="col-12 col-sm-6 col-md-4">
            <!-- <div class="shadow-sm p-3 mb-3 bg-white rounded"> -->
            <img src="{{asset('assets/frontend/assets/footer/niccp.png') }}" alt="NICCP Certification" class="footer-cert rounded" />
            <!-- </div> -->
            <p class="small text-light">
              National Institute of Certified College Planners
            </p>
          </div>
        </div>
      </div>

      <!-- Bottom -->
      <div class="footer-bottom d-flex flex-column flex-lg-row justify-content-between align-items-center">
        <p class="mb-2 mb-lg-0">© 2025 College Connect 101. All Rights Reserved.</p>
        <div class="d-flex gap-3">
          <a href="{{route('termconditions')}}">Terms and Conditions</a>
        </div>
      </div>
    </div>
  </footer>

  <!-- Filter Modal (Mobile) -->
  <div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="filterModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
              <div class="modal-header border-0">
                  <h5 class="modal-title text-primary-orange" id="filterModalLabel">View Options</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                  <div class="d-grid gap-3">
                      <button class="btn btn-outline-primary-orange text-start" id="modalByStateBtn"
                          data-bs-dismiss="modal">
                          <i class="bi bi-geo-alt-fill me-2"></i> Acceptances by State
                      </button>
                      <button class="btn btn-outline-primary-orange text-start" id="modalPrestigiousBtn"
                          data-bs-dismiss="modal">
                          <i class="bi bi-award-fill me-2"></i> Featured Prestigious
                      </button>
                  </div>
              </div>
          </div>
      </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    xintegrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>