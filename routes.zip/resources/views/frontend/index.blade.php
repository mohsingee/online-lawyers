@extends('frontend.layouts.master')
@section('content')
<!-- hero section  -->
  <section id="hero" class="vh-100 position-relative overflow-hidden">
    <div id="heroCarousel" class="carousel heroCarousel slide h-100" data-bs-ride="carousel" data-bs-interval="5000">
      <div class="carousel-inner h-100">
        <div class="carousel-item active h-100"
          data-image="https://images.unsplash.com/photo-1747836503551-e99b42c30743?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwc3R1ZGVudHMlMjBzdHVkeWluZyUyMGdyYWR1YXRpb24lNDNlbnwx%7C%7CxfHx8fDE3NTg2MzM4OTR8MA&ixlib=rb-4.1.0&q=80&w=1080"
          data-gradient="linear-gradient(135deg, rgba(225, 133, 82, 0.8), rgba(255, 107, 53, 0.8))">
          <div class="slide-progress"></div>
          <div class="d-flex align-items-center h-100 text-white">
            <div class="container text-start animate-text">
              <div class="row">
                <div class="col-lg-8">
                  <h1 class="display-3 fw-bold mb-4">College Success Path</h1>
                  <h2 class="h3 mb-4 text-white-75">
                    We can take the stress out of the college admission
                    process
                  </h2>
                  <p class="lead mb-5 text-white-75">
                    Expert guidance from test prep to acceptance letters
                  </p>
                  <a href="#contact" class="btn orange-bg text-white btn-lg px-5 py-3 rounded-pill">
                    Get Started Today
                    <i class="bi bi-arrow-right ms-2"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="carousel-item h-100"
          data-image="https://images.unsplash.com/photo-1728456354829-f7cbbf3122a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwYXBwbGljYXRpb24lMjBlc3NheSUyMHdyaXRpbmd8ZW58MXx8fHwxNzU4NjMzODk4fDA&ixlib=rb-4.1.0&q=80&w=1080"
          data-gradient="linear-gradient(135deg, rgba(225, 133, 82, 0.8), rgba(45, 253, 197, 0.8))">
          <div class="slide-progress"></div>
          <div class="d-flex align-items-center h-100 text-white">
            <div class="container text-start animate-text">
              <div class="row">
                <div class="col-lg-8">
                  <h1 class="display-3 fw-bold mb-4">
                    Expert Essay Coaching
                  </h1>
                  <h2 class="h3 mb-4 text-white-75">
                    Craft compelling personal statements that stand out
                  </h2>
                  <p class="lead mb-5 text-white-75">
                    Professional guidance to tell your unique story
                  </p>
                  <a href="#contact" class="btn orange-bg text-white btn-lg px-5 py-3 rounded-pill">
                    Get Started Today
                    <i class="bi bi-arrow-right ms-2"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="carousel-item h-100"
          data-image="https://images.unsplash.com/photo-1653945475227-596b295cff01?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwZmluYW5jaWFsJTIwYWlkJTIwc2Nob2xhcnNoaXB8ZW58MXx8fHwxNzU4NjMzOTAzfDA&ixlib=rb-4.1.0&q=80&w=1080"
          data-gradient="linear-gradient(135deg, rgba(34, 193, 195, 0.8), rgba(45, 253, 197, 0.8))">
          <div class="slide-progress"></div>
          <div class="d-flex align-items-center h-100 text-white">
            <div class="container text-start animate-text">
              <div class="row">
                <div class="col-lg-8">
                  <h1 class="display-3 fw-bold mb-4">
                    Financial Aid Mastery
                  </h1>
                  <h2 class="h3 mb-4 text-white-75">
                    Maximize scholarships and financial assistance
                  </h2>
                  <p class="lead mb-5 text-white-75">
                    Navigate FAFSA, CSS Profile, and award negotiations
                  </p>
                  <a href="#contact" class="btn orange-bg text-white btn-lg px-5 py-3 rounded-pill">
                    Get Started Today
                    <i class="bi bi-arrow-right ms-2"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Enhanced Navigation Controls - Bottom Right -->
      <div class="slider-controls">
        <!-- Navigation Arrows -->
        <button class="nav-arrow" id="prevSlide" title="Previous slide">
          <i class="bi bi-chevron-left"></i>
        </button>

        <!-- Slide Indicators -->
        <div class="slide-indicators">
          <button type="button" data-slide-to="0" class="hero-indicator active" aria-label="Slide 1"></button>
          <button type="button" data-slide-to="1" class="hero-indicator" aria-label="Slide 2"></button>
          <button type="button" data-slide-to="2" class="hero-indicator" aria-label="Slide 3"></button>
        </div>

        <button class="nav-arrow" id="nextSlide" title="Next slide">
          <i class="bi bi-chevron-right"></i>
        </button>

        <!-- Play/Pause Button -->
        <button class="play-pause-btn" id="playPauseBtn" title="Pause slideshow">
          <i id="playPauseIcon" class="bi bi-pause-fill"></i>
        </button>
      </div>
    </div>
  </section>

  <!-- Results Section -->
  <section class="py-5 section-gradient-1">
    <div class="container">
      <div class="text-center mb-5" data-aos="fade-up">
        <h2 class="display-5 fw-bold display-enhanced mb-4">
          Proven Results That Speak
        </h2>
        <p class="h4 text-secondary">
          Real outcomes from our comprehensive college consulting services
        </p>
      </div>
      <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
        <div class="col" data-aos="fade-up" data-aos-delay="100">
          <div class="stats-card enhanced-card h-100 p-4 text-center">
            <i class="bi bi-bullseye icon-enhanced fs-1 orange-text mb-3 float-animation"></i>
            <div class="stats-number">95%</div>
            <p class="text-secondary mb-0">
              Students accepted to top 3 choices
            </p>
          </div>
        </div>
        <div class="col" data-aos="fade-up" data-aos-delay="200">
          <div class="stats-card enhanced-card h-100 p-4 text-center">
            <i class="bi bi-cash-stack icon-enhanced fs-1 orange-text mb-3 float-animation"
              style="animation-delay: 0.5s"></i>
            <div class="stats-number">$2.5M+</div>
            <p class="text-secondary mb-0">
              Additional financial aid secured
            </p>
          </div>
        </div>
        <div class="col" data-aos="fade-up" data-aos-delay="300">
          <div class="stats-card enhanced-card h-100 p-4 text-center">
            <i class="bi bi-people-fill icon-enhanced fs-1 orange-text mb-3 float-animation"
              style="animation-delay: 1s"></i>
            <div class="stats-number">500+</div>
            <p class="text-secondary mb-0">Students successfully placed</p>
          </div>
        </div>
        <div class="col" data-aos="fade-up" data-aos-delay="400">
          <div class="stats-card enhanced-card h-100 p-4 text-center">
            <i class="bi bi-award-fill icon-enhanced fs-1 orange-text mb-3 float-animation"
              style="animation-delay: 1.5s"></i>
            <div class="stats-number">15+</div>
            <p class="text-secondary mb-0">Years of experience</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Services Section -->
  <section class="py-5 bg-white">
    <div class="container">
      <div class="text-center mb-5" data-aos="fade-up">
        <h2 class="display-5 fw-bold   mb-4">
          Our <span class="orange-text">Comprehensive Services</span>
        </h2>
        <p class=" text-secondary">
          Everything you need for college admission success
        </p>
      </div>
      <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <div class="col" data-aos="fade-up" data-aos-delay="100">
          <div class="service-card enhanced-card h-100 p-4" style="background: var(--gradient-2)">
            <div class="card-body">
              <i class="bi bi-book-half icon-enhanced fs-1 orange-text mb-4"></i>
              <h3 class="h4 fw-bold mb-3">Comprehensive Planning</h3>
              <p class="text-secondary mb-4">
                Full-service college consulting from freshman year through
                acceptance
              </p>
              <ul class="list-unstyled">
                <li class="d-flex align-items-center mb-2">
                  <i class="bi bi-check-circle-fill orange-text me-2"></i>
                  4-Year Strategic Planning
                </li>
                <li class="d-flex align-items-center mb-2">
                  <i class="bi bi-check-circle-fill orange-text me-2"></i>
                  Academic Course Selection
                </li>
                <li class="d-flex align-items-center">
                  <i class="bi bi-check-circle-fill orange-text me-2"></i>
                  Extracurricular Guidance
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col" data-aos="fade-up" data-aos-delay="200">
          <div class="service-card enhanced-card h-100 p-4" style="background: var(--gradient-2)">
            <div class="card-body">
              <i class="bi bi-pen-fill icon-enhanced fs-1 orange-text mb-4"></i>
              <h3 class="h4 fw-bold mb-3">Essay Excellence</h3>
              <p class="text-secondary mb-4">
                Professional coaching for personal statements and supplemental
                essays
              </p>
              <ul class="list-unstyled">
                <li class="d-flex align-items-center mb-2">
                  <i class="bi bi-check-circle-fill orange-text me-2"></i>
                  Brainstorming Sessions
                </li>
                <li class="d-flex align-items-center mb-2">
                  <i class="bi bi-check-circle-fill orange-text me-2"></i>
                  Multiple Draft Reviews
                </li>
                <li class="d-flex align-items-center">
                  <i class="bi bi-check-circle-fill orange-text me-2"></i>
                  Interview Preparation
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col" data-aos="fade-up" data-aos-delay="300">
          <div class="service-card enhanced-card h-100 p-4" style="background: var(--gradient-2)">
            <div class="card-body">
              <i class="bi bi-calculator-fill icon-enhanced fs-1 orange-text mb-4"></i>
              <h3 class="h4 fw-bold mb-3">Financial Strategy</h3>
              <p class="text-secondary mb-4">
                Expert guidance on financial aid and scholarship opportunities
              </p>
              <ul class="list-unstyled">
                <li class="d-flex align-items-center mb-2">
                  <i class="bi bi-check-circle-fill orange-text me-2"></i>
                  FAFSA & CSS Assistance
                </li>
                <li class="d-flex align-items-center mb-2">
                  <i class="bi bi-check-circle-fill orange-text me-2"></i>
                  Merit Aid Maximization
                </li>
                <li class="d-flex align-items-center">
                  <i class="bi bi-check-circle-fill orange-text me-2"></i>
                  Award Negotiation
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- What We Do Section -->
  <section class="py-5 section-gradient-1">
    <div class="container">
      <div class="text-center mb-5" data-aos="fade-up">
        <h2 class="display-5 fw-bold ">What<span class="orange-text"> We Do</span></h2>
      </div>
      <div class="row g-5 align-items-center">
        <div class="col-lg-6" data-aos="fade-right">
          <p class=" text-secondary mb-4">
            We are Independent Educational Consultants (IEC) dedicated to
            helping families navigate the rigors of the college application
            process. We offer objective advice, access to reliable
            information, and the kind of individual attention necessary to
            make an informed decision.
          </p>
          <p class=" text-secondary mb-4">
            Finding the right school, college or program can be a rewarding
            process, but for some families, the experience is challenging,
            overwhelming and at times frustrating. Few decisions have as great
            an impact on a student. Families may find themselves at a loss to
            properly evaluate their options and make appropriate choices.
          </p>
          <p class=" text-secondary">
            For families considering college, the main reason to hire an IEC
            is our individualized attention and firsthand knowledge of
            hundreds of educational opportunities. Most high school guidance
            counselors would like to assist students individually, but they
            have too many students to manage.
          </p>
        </div>
        <div class="col-lg-6" data-aos="fade-left">
          <div class="row row-cols-1 row-cols-md-2 g-4">
            <div class="col">
              <div class="enhanced-card h-100 p-4 text-center"
                style="background: linear-gradient(135deg, #fffaf0, #fff3e6)">
                <i class="bi bi-person-fill icon-enhanced fs-1 orange-text mb-3"></i>
                <h3 class="h5 fw-bold mb-2">Personalized Attention</h3>
                <p class="text-secondary mb-0">
                  Individual guidance for every student
                </p>
              </div>
            </div>
            <div class="col">
              <div class="enhanced-card h-100 p-4 text-center"
                style="background: linear-gradient(135deg, #eaf4ff, #d6eaff)">
                <i class="bi bi-mortarboard-fill icon-enhanced fs-1 orange-text mb-3"></i>
                <h3 class="h5 fw-bold mb-2">Expert Knowledge</h3>
                <p class="text-secondary mb-0">
                  Hundreds of educational opportunities
                </p>
              </div>
            </div>
            <div class="col">
              <div class="enhanced-card h-100 p-4 text-center"
                style="background: linear-gradient(135deg, #e9f9ee, #ccefd8)">
                <i class="bi bi-bullseye icon-enhanced fs-1 orange-text mb-3"></i>
                <h3 class="h5 fw-bold mb-2">Best Fit Schools</h3>
                <p class="text-secondary mb-0">
                  95% acceptance rate to top 3 choices
                </p>
              </div>
            </div>
            <div class="col">
              <div class="enhanced-card h-100 p-4 text-center"
                style="background: linear-gradient(135deg, #f2e9f7, #e0c8ed)">
                <i class="bi bi-award-fill icon-enhanced fs-1 orange-text mb-3"></i>
                <h3 class="h5 fw-bold mb-2">Proven Results</h3>
                <p class="text-secondary mb-0">Track record of success</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Mission Section -->
  <section class="py-5 section-gradient-3">
    <div class="container text-center" data-aos="fade-up">
      <h2 class="display-5 fw-bold  mb-5">Our<span class="orange-text"> Mission</span> </h2>
      <p class="lead text-secondary mx-auto mb-4" style="max-width: 800px">
        We are dedicated to taking as much of the stress out of the college
        admission process and become an objective, third-party, helping you
        through the process of transitioning from high school and the comforts
        of living at home to going off to college and experiencing
        independence.
      </p>
      <p class="lead text-secondary mx-auto" style="max-width: 800px">
        We are experts at finding the
        <span class="orange-text fw-bold">"Best Fit"</span> school, one that
        will help foster both the student's academic and social growth.
      </p>
    </div>
  </section>

  <!-- Process Section -->
  <section class="py-5 bg-white">
    <div class="container">
      <div class="text-center mb-5" data-aos="fade-up">
        <h2 class="display-5 fw-bold display-enhanced mb-4">
          The College Connect 101 Process
        </h2>
        <p class="h4 text-secondary">
          Our proven 4-step methodology for college success
        </p>
      </div>
      <div class="row row-cols-1 row-cols-md-2 g-4">
        <div class="col" data-aos="fade-up" data-aos-delay="100">
          <div class="process-card enhanced-card h-100 p-4" style="background: var(--gradient-3)">
            <div class="process-section align-items-start">
              <div class="flex-shrink-0 me-4">
                <span
                  class="process-number d-inline-flex align-items-center justify-content-center text-white fs-4 fw-bold rounded-circle">1</span>
              </div>
              <div>
                <h3 class="h5 fw-bold mb-3">Standard Test Prep</h3>
                <p class="text-secondary">
                  We first give you access to a SAT and/or ACT practice test
                  given in an actual test environment by a proctor. After we
                  receive the results of your testing, we prep on either the
                  ACT OR SAT test which includes (5) individualized sessions
                  (1hr each) instructing on proven test-taking strategies for
                  your optimal score.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="col" data-aos="fade-up" data-aos-delay="200">
          <div class="process-card enhanced-card h-100 p-4" style="background: var(--gradient-3)">
            <div class="process-section align-items-start">
              <div class="flex-shrink-0 me-4">
                <span
                  class="process-number d-inline-flex align-items-center justify-content-center text-white fs-4 fw-bold rounded-circle">2</span>
              </div>
              <div>
                <h3 class="h5 fw-bold mb-3">Build the College List</h3>
                <p class="text-secondary">
                  We create a best-fit college list based on our years of
                  industry knowledge, using data points obtained from the
                  result of our personality profile survey, combined with your
                  academic and extracurricular profile. Over 95% of our
                  students are accepted into one of their top three schools.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="col" data-aos="fade-up" data-aos-delay="300">
          <div class="process-card enhanced-card h-100 p-4" style="background: var(--gradient-3)">
            <div class="process-section align-items-start">
              <div class="flex-shrink-0 me-4">
                <span
                  class="process-number d-inline-flex align-items-center justify-content-center text-white fs-4 fw-bold rounded-circle">3</span>
              </div>
              <div>
                <h3 class="h5 fw-bold mb-3">
                  Craft Essays and Complete Applications
                </h3>
                <p class="text-secondary">
                  Our expert essay coaches will assist you with brainstorming
                  and topic selection. We will also teach you how to develop
                  and craft your personal statement in addition to all of your
                  individual school supplemental essays. Our coaches will walk
                  you through the entire process.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="col" data-aos="fade-up" data-aos-delay="400">
          <div class="process-card enhanced-card h-100 p-4" style="background: var(--gradient-3)">
            <div class="process-section items-start">
              <div class="flex-shrink-0 me-4 mb-2">
                <span
                  class="process-number d-inline-flex align-items-center justify-content-center text-white fs-4 fw-bold rounded-circle">4</span>
              </div>
              <div>
                <h3 class="h5 fw-bold ">Financial Aid Advisory</h3>
                <p class="text-secondary">
                  We will work one-on-one with your family to provide
                  assistance with your school-specific financial aid forms,
                  FAFSA, CSS Profile, IDOC documents, and Verification Forms.
                  Most of our clients are successful in securing additional
                  financial aid based on our industry expertise.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Testimonials Section -->
  <section class="testimonials-section py-5">
    <div class="container">
      <h2 class="display-5 fw-bold text-center mb-5">
        What Our <span class="orange-text">Clients Are Saying</span>
      </h2>

      <div class="row justify-content-center">
        <div class="col-12 col-lg-10 testimonial-carousel-container">

          <!-- Bootstrap Carousel -->
          <div id="testimonialCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="8000">
            <!-- Controls -->
            <div class=" main-carousel-controls ">
              <button class="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#testimonialCarousel"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
            <!-- Indicators -->
            <div class="carousel-indicators">
              <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="0" class="active"
                aria-current="true" aria-label="Slide 1"></button>
              <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="1"
                aria-label="Slide 2"></button>
              <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="2"
                aria-label="Slide 3"></button>
              <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="3"
                aria-label="Slide 4"></button>
              <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="4"
                aria-label="Slide 5"></button>
              <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="5"
                aria-label="Slide 6"></button>
              <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="6"
                aria-label="Slide 7"></button>
              <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="7"
                aria-label="Slide 8"></button>
              <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="8"
                aria-label="Slide 9"></button>
              <button type="button" data-bs-target="#testimonialCarousel" data-bs-slide-to="9"
                aria-label="Slide 10"></button>
            </div>

            <!-- Carousel Inner Content -->
            <div class="carousel-inner">

              <!-- Slide 1 -->
              <div class="carousel-item active">
                <div class="testimonial-card">
                  <div class="testimonial-text-wrapper">
                    <!-- The 'collapse' class makes it expandable/collapsible, and our custom CSS controls the max-height when .show is absent -->
                    <div class="testimonial-text collapse" id="collapseText1">
                      <p>We interviewed several college advisors and I’d say we made a brilliant choice!! From start to finish the College Connect 101 team was involved in all aspects of the process. Starting with the “Find your Path” survey and finishing with valuable insight which ultimately helped my daughters decide where they would spend their next four years. Creating a college list, setting realistic goals, course loads, ACT, SAT prep, application process, essay writing, financial aid, and overall “straight talk” with our daughters when we couldn’t get through to them.</p>
                      <p>Gigi and her team assisted both of my daughters and between the two of them, they were excepted into 30 colleges finally deciding on Univ. of Portland (nursing program) and Harvard. It’s a long process with so many steps along the way, but Gigi and her team kept them on task which took a TON of pressure off of us parents during those rebellious yet critical times. Do yourself a favor, this is a complicated process, let Gigi and the College Connect 101 team help you navigate through it. So happy we chose College Connect 101!</p>
                    </div>
                    <!-- The button uses Bootstrap's data attributes to control the corresponding collapse element -->
                    <a class="read-more-btn" data-bs-toggle="collapse" href="#collapseText1" role="button"
                      aria-expanded="false" aria-controls="collapseText1">Read More</a>
                  </div>
                  <div class="testimonial-footer">
                    <div class="client-name">J. and D. Jones</div>
                    <div class="client-school">Harvard University & University of Portland Parents</div>
                  </div>
                </div>
              </div>

              <!-- Slide 2 -->
              <div class="carousel-item">
                <div class="testimonial-card">
                  <div class="testimonial-text-wrapper">
                    <div class="testimonial-text collapse" id="collapseText2">
                    <p>College Connect 101 has been instrumental in helping my daughter pick schools, coaching her with all of her essay prompts, and guiding her through the entire application process for all of the schools she was applying to. Gigi was a God sent as being a single mom, I felt so overwhelmed with the many deadlines and information required. Her guidance, support and knowledge helped my daughter get into her first choice, and now I can say I am the proud mother of a Brown University student.
                    </p>  
                    <p>With College Connect's help, Hannah was accepted to all five universities where she applied: Brown, University of Chicago, Tulane, Case Western, and Fordham.</p>
                    <p>I can only say that they put their heart and soul into our applications, constantly reviewing our essays, pushing Hannah to challenge herself resulting in admission into her "Dream School", and I can't help but to show my gratitude for Gigi and her team at College Connect 101!</p>
                  </div>
                    <a class="read-more-btn" data-bs-toggle="collapse" href="#collapseText2" role="button"
                      aria-expanded="false" aria-controls="collapseText2">Read More</a>
                  </div>
                  <div class="testimonial-footer">
                    <div class="client-name">B.Jennings</div>
                    <div class="client-school">Brown University Parent</div>
                  </div>
                </div>
              </div>

              <!-- Slide 3 -->
              <div class="carousel-item">
                <div class="testimonial-card">
                  <div class="testimonial-text-wrapper">
                    <div class="testimonial-text collapse" id="collapseText3">
                      <p>My wife and I can't thank College Connect 101 enough for helping our son and daughter with the
                        college application process, including financial aid. Many times you went the extra yard for our
                        family. Only with your guidance and attention to detail that those applications and forms
                        required did our college dream for our children become a reality. We would ask you again, in a
                        heartbeat, to help us if we had to do this all over again. GO IRISH! and GO BRONCOS!</p>
                    </div>
                    <a class="read-more-btn" data-bs-toggle="collapse" href="#collapseText3" role="button"
                      aria-expanded="false" aria-controls="collapseText3">Read More</a>
                  </div>
                  <div class="testimonial-footer">
                    <div class="client-name">M. Partyka</div>
                    <div class="client-school">Notre Dame University & Boise State University Parent</div>
                  </div>
                </div>
              </div>

              <!-- Slide 4 -->
              <div class="carousel-item">
                <div class="testimonial-card">
                  <div class="testimonial-text-wrapper">
                    <div class="testimonial-text collapse" id="collapseText4">
                      <p>Thanks to College Connect 101’s expertise and personal engagement, our family managed the
                        daunting college application process with ease. College Connect 101's services surpassed my
                        expectations at a surprisingly affordable rate. They committed countless personalized hours to
                        our student, focusing on career goal development, school and major research, resume building,
                        essay review, financial consultation, and accuracy of data entry. Their attention to detail was
                        exceptional!</p>
                    </div>
                    <a class="read-more-btn" data-bs-toggle="collapse" href="#collapseText4" role="button"
                      aria-expanded="false" aria-controls="collapseText4">Read More</a>
                  </div>
                  <div class="testimonial-footer">
                    <div class="client-name">S. Patel</div>
                    <div class="client-school">UCLA and University of Arizona Parent I. Bryan</div>
                  </div>
                </div>
              </div>

              <!-- Slide 5 -->
              <div class="carousel-item">
                <div class="testimonial-card">
                  <div class="testimonial-text-wrapper">
                    <div class="testimonial-text collapse" id="collapseText5">
                      <p>College Connect 101 took the stress out the College app process! We would have not had the same
                        experience or outcome without Gigi’s strategic knowledge and insight. My husband and I cannot
                        thank College Connect enough. With our daughter being a performing arts major, she had a host of
                        options. We were simply unsure of the best fit for her next academic adventure. In addition,
                        Jordyn was booked on a major television show during the college application season so it was
                        critical that we had a partner and consultant that could help us get the job done.</p>
                        <p>As a result, I am thrilled to say that my daughter was accepted into her Top 2 choices and had so many other options to choose from!</p>
                    </div>
                    <a class="read-more-btn" data-bs-toggle="collapse" href="#collapseText5" role="button"
                      aria-expanded="false" aria-controls="collapseText5">Read More</a>
                  </div>
                  <div class="testimonial-footer">
                    <div class="client-name">M. Warren</div>
                    <div class="client-school">USC Parent</div>
                  </div>
                </div>
              </div>

              <!-- Slide 6 -->
              <div class="carousel-item">
                <div class="testimonial-card">
                  <div class="testimonial-text-wrapper">
                    <div class="testimonial-text collapse" id="collapseText6">
                      <p>I cannot thank College Connect 101 enough for all that they have done for both of my sons! Gigi is extremely strategic and knowledgeable especially when it comes to financial aid. She gave us ideas and suggestions on how to get more grants and scholarships directly from the school.</p>
                      <p>My oldest son just graduated from NYU and Gigi was able to secure a $20,000 grant four years in a row. In addition to that she expertly crafted our appeal letters which lead to more grants & scholarships. Our youngest son was originally awarded $5,000 in grants this year, but with Gigi's amazing guidance, that $5,000 turned into over $40,000 in grants and scholarships! We haven't taken out any loans so far! I would DEFINITELY recommend using Gigi's services to guide you throughout your entire college process.</p>
                    </div>
                    <a class="read-more-btn" data-bs-toggle="collapse" href="#collapseText6" role="button"
                      aria-expanded="false" aria-controls="collapseText6">Read More</a>
                  </div>
                  <div class="testimonial-footer">
                    <div class="client-name">M. Givens</div>
                    <div class="client-school">New York University & University of San Francisco Parent</div>
                  </div>
                </div>
              </div>

              <!-- Slide 7 -->
              <div class="carousel-item">
                <div class="testimonial-card">
                  <div class="testimonial-text-wrapper">
                    <div class="testimonial-text collapse" id="collapseText7">
                      <p>I cannot sing the praises of College Connect 101 loudly enough. The professionalism and expertise of this phenomenal service are unmatched. They were able to guide us step by step through the testing, application and admission process with years of experience and industry knowledge through programs I had no idea even existed.</p>
                      <p>Through the access to all of the comprehensive services provided by College Connect 101, my daughter was able to secure 17 college admission letters, and ultimately CC 101 helped with securing scholarships that have practically covered the cost of a private college education. I do not know where I would be without the services of College Connect 101. They are the South Bay's best-kept secret for college planning/guidance and financial assistance service needs. I happily recommend College Connect 101 to any parent for pre and post-college guidance and services.</p>
                    </div>
                    <a class="read-more-btn" data-bs-toggle="collapse" href="#collapseText7" role="button"
                      aria-expanded="false" aria-controls="collapseText7">Read More</a>
                  </div>
                  <div class="testimonial-footer">
                    <div class="client-name">K. Curry</div>
                    <div class="client-school">Santa Clara University & UCI Law School Parent</div>
                  </div>
                </div>
              </div>

              <!-- Slide 8 -->
              <div class="carousel-item">
                <div class="testimonial-card">
                  <div class="testimonial-text-wrapper">
                    <div class="testimonial-text collapse" id="collapseText8">
                      <p>I have used College Connect 101 for two consecutive years to complete my daughter’s FAFSA, for
                        financial aid advice and for scholarship advice and it has been a lifesaver! Gigi was able to
                        successfully appeal a parent loan denial prior to my daughter entering her first year of
                        college. I did not encounter any residual financial aid difficulties when I used College Connect
                        101 to enroll my daughter for her second year of college. I highly recommend utilizing College
                        Connect 101 for all of your college financial needs whether you’re a parent of a current or a
                        prospective college student!</p>
                    </div>
                    <a class="read-more-btn" data-bs-toggle="collapse" href="#collapseText8" role="button"
                      aria-expanded="false" aria-controls="collapseText8">Read More</a>
                  </div>
                  <div class="testimonial-footer">
                    <div class="client-name">D. Siegel</div>
                    <div class="client-school">University of Washington & University of Colorado Parent</div>
                  </div>
                </div>
              </div>

              <!-- Slide 9 -->
              <div class="carousel-item">
                <div class="testimonial-card">
                  <div class="testimonial-text-wrapper">
                    <div class="testimonial-text collapse" id="collapseText9">
                      <p>After looking for other similar service providers we chose College Connect 101. First, we connected my nephew who received tremendous help with essay and financial aid and he ended up accepted by UC Berkeley.</p>
                      <p>Last year, my son, got a comprehensive service including SAT tutoring as well as assistance on essays. He applied to the top twenty schools in the country and ended up getting accepted to 11 top-notch schools. Our investment truly paid off. Gigi’s knowledge in the college application and all the other essentials details that come with it is superb.</p>
                    </div>
                    <a class="read-more-btn" data-bs-toggle="collapse" href="#collapseText9" role="button"
                      aria-expanded="false" aria-controls="collapseText9">Read More</a>
                  </div>
                  <div class="testimonial-footer">
                    <div class="client-name">A. Hagos</div>
                    <div class="client-school">Loyola Marymount University Parent</div>
                  </div>
                </div>
              </div>

              <!-- Slide 10 -->
              <div class="carousel-item">
                <div class="testimonial-card">
                  <div class="testimonial-text-wrapper">
                    <div class="testimonial-text collapse" id="collapseText10">
                      <p>It’s never too late! I didn’t think we needed help with college applications and financial aid. My daughter’s high school provided college counseling and I applied to college (26 years ago!), so I thought we had it under control. From the first meeting with College Connect 101, it was clear that we were in over our heads. The application process seemed extremely confusing, the competition is fierce and frankly, I didn’t have the time I wanted to devote to the process. They demystified the process, took the burden of maneuvering through the maze, and provided my daughter the comfort that she was working with professionals who knew what they were doing.</p>
                      <p>Once my daughter made the decision on the university she wanted to attend, we were disappointed because we don’t qualify for that much financial need, but we also couldn’t write a check for private college tuition, so it was a God-send that College Connect 101 stepped in and helped secure an extra $20k/over the four years. That made all the difference and we could send in the ‘accepted’ decision to the university.</p>
                      <p>Would we go with College Connect 101 again for our current 9th grader? Yes!
                      </p>
                    </div>
                    <a class="read-more-btn" data-bs-toggle="collapse" href="#collapseText10" role="button"
                      aria-expanded="false" aria-controls="collapseText10">Read More</a>
                  </div>
                  <div class="testimonial-footer">
                    <div class="client-name">T. Djedjro</div>
                    <div class="client-school">American University Parent</div>
                  </div>
                </div>
              </div>

            </div>

            <!-- Controls -->
            <!-- <button class="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button> -->
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Call to Action Section -->
  <section class="contact-section text-center" data-aos="fade-up">
    <div class="container">
        <h2 class="orange-text" style="font-size: 1.875rem; font-weight: 700; margin-bottom: 1.5rem;">Need Help
            Scheduling?</h2>
        <p style="font-size: 1.125rem; color: var(--gray-700); margin-bottom: 2rem;">
            If you have any questions or need assistance, don't hesitate to contact us directly.
        </p>
        <div class="contact-buttons">
            <a href="tel:4248002248" class="contact-button">
                <svg class="lucide-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path
                        d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-4.71-4.71A19.79 19.79 0 0 1 2 4.18 2 2 0 0 1 4.18 2h3a2 2 0 0 1 2 2.18 15.28 15.28 0 0 0 .79 4.45 2 2 0 0 1-1.25 2.12c-.17.1-.34.2-.5.31A19.53 19.53 0 0 0 10 16.5a19.53 19.53 0 0 0 4.16-2.58c.11-.16.21-.33.31-.5a2 2 0 0 1 2.12-1.25z" />
                </svg>
                Call (424) 800-2248
            </a>
            <a href="#" class="contact-button">
                <svg class="lucide-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect width="20" height="16" x="2" y="4" rx="2" />
                    <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                </svg>
                Email Us
            </a>
        </div>
    </div>
</section>
@endsection