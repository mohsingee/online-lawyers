@extends('frontend.layouts.master')
@section('content')
    <div id="app">
      <!-- Hero Section -->
      <section class="hero-section" data-aos="fade-up" data-aos-duration="800">
        <div
          class="container text-center"
          data-aos="fade-up"
          data-aos-duration="800"
        >
          <h1>Make an <span class="orange-text">Appointment</span></h1>
          <p>
            Schedule your personalized consultation with our expert college
            planning team
          </p>
        </div>
      </section>

      <!-- Calendly Inline Embed Section -->
      <section
        class="calendly-section py-5"
        data-aos="fade-up"
        data-aos-duration="800"
      >
        <div class="container text-center">
          <h2 class="orange-text mb-4 d-none">Book Your Appointment</h2>
          <p class="mb-2">
            Select a convenient time below to schedule your personalized
            60-minute consultation.
          </p>
          <!-- Calendly Inline Embed -->
          <div
            class="calendly-inline-widget"
            data-url="https://calendly.com/collegeconnect101/60min"
            style="min-width: 320px; height: 700px"
          ></div>
          <script
            type="text/javascript"
            src="https://assets.calendly.com/assets/external/widget.js"
            async
          ></script>
        </div>
      </section>

      <!-- Call to Action Section -->
      <section class="contact-section text-center" data-aos="fade-up">
        <div class="container">
          <h2
            class="orange-text"
            style="font-size: 1.875rem; font-weight: 700; margin-bottom: 1.5rem"
          >
            Need Help Scheduling?
          </h2>
          <p
            style="
              font-size: 1.125rem;
              color: var(--gray-700);
              margin-bottom: 2rem;
            "
          >
            If you have any questions or need assistance, don't hesitate to
            contact us directly.
          </p>
          <div class="contact-buttons">
            <a href="tel:4248002248" class="contact-button">
              <svg
                class="lucide-icon"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
              >
                <path
                  d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-4.71-4.71A19.79 19.79 0 0 1 2 4.18 2 2 0 0 1 4.18 2h3a2 2 0 0 1 2 2.18 15.28 15.28 0 0 0 .79 4.45 2 2 0 0 1-1.25 2.12c-.17.1-.34.2-.5.31A19.53 19.53 0 0 0 10 16.5a19.53 19.53 0 0 0 4.16-2.58c.11-.16.21-.33.31-.5a2 2 0 0 1 2.12-1.25z"
                />
              </svg>
              Call (424) 800-2248
            </a>
            <a href="#" class="contact-button">
              <svg
                class="lucide-icon"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
              >
                <rect width="20" height="16" x="2" y="4" rx="2" />
                <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
              </svg>
              Email Us
            </a>
          </div>
        </div>
      </section>
    </div>
@endsection