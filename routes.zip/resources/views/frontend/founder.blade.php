@extends('frontend.layouts.master')
@section('content')
<!-- Hero Section -->
<section class="hero-section">
    <div class="container" data-aos="fade-up" data-aos-duration="800">
        <h1 data-aos="fade-up" data-aos-delay="100">Our <span class="orange-text">Founder</span></h1>
        <p data-aos="fade-up" data-aos-delay="200">
            Meet the visionary behind College Connect 101's proven methodology for college success
        </p>
    </div>
</section>

<!-- Main Profile Section -->
<section class="py-5 bg-white">
    <div class="container">
        <div class="row g-5 align-items-center">
            <div class="col-lg-6" data-aos="fade-right" data-aos-duration="800">
                <div class="mb-4">
                    <h2 class="display-5 orange-text" data-aos="fade-up" data-aos-delay="100">Gigi Frye</h2>
                    <p class="lead text-secondary" data-aos="fade-up" data-aos-delay="150">President / CEO</p>
                    <div class="d-flex gap-2 mt-3 flex-wrap" data-aos="fade-up" data-aos-delay="200">
                        <span class="badge-enhanced text-white">Educational Consultant</span>
                        <span class="badge-enhanced text-white">Financial Aid Expert</span>
                    </div>
                </div>
                <div class="d-grid gap-3">
                    <p class="text-secondary" data-aos="fade-up" data-aos-delay="250">After her realization that
                        valuable information on how to fund her daughter's college education was not readily
                        available, Gigi sought out to personally demystify the stressful process of obtaining
                        adequate financial aid. In short time, Gigi had diligently researched various sources of
                        financing, and through that daunting experience learned firsthand the tools of the trade.
                    </p>
                    <p class="text-secondary" data-aos="fade-up" data-aos-delay="300">As a result of her extensive
                        research and the professional guidance of several college financial aid administrators, she
                        gleaned valuable insight that enabled her to develop a proven methodology for obtaining the
                        maximum amount of financial aid possible. All of her hard work came to fruition when her
                        daughter was fortunate to graduate from Loyola Marymount University without any student
                        debt.</p>
                </div>
            </div>
            <div class="col-lg-6 d-flex justify-content-center" data-aos="fade-left" data-aos-duration="800">
                <div class="founder-image-card w-100 aos-container" style="max-width: 350px;">
                    <div class="founder-image-container" data-aos="zoom-in" data-aos-delay="400">
                        <img src="{{ asset('assets/frontend/assets/about/about.png')}}" alt="Gigi Frye, President & CEO of College Connect 101"
                            class="founder-image">
                        <div class="founder-image-overlay">
                            <h3 class="h4 mb-2">Gigi Frye</h3>
                            <p class="mb-0 opacity-90">President & CEO</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Journey Section -->
<section class="py-5 section-gradient-1">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up" data-aos-duration="800">
            <h2 class="display-6 display-enhanced">Gigi's Journey to Excellence</h2>
        </div>
        <div class="d-grid gap-4 fs-5 text-secondary" style="max-width: 900px; margin: 0 auto;">
            <p data-aos="fade-up" data-aos-delay="100">Empowered by her success, Gigi founded College Connect 101 in
                2010 with the mission of helping families overcome the challenges of college affordability for their
                children. After a few years of working exclusively with financial aid, Gigi realized that if she
                could work with students to help them navigate through the rigors of the application process,
                enabling them to submit their best overall application, they would receive more merit aid which will
                inevitably help to offset the total cost of tuition.</p>
            <p data-aos="fade-up" data-aos-delay="150">To learn more about the college application process, she
                joined professional organizations such as the Independent Educational Consultants Association (IECA)
                and the National Association for College Admission Counseling (NACAC) to learn best practices which
                she uses to continuously place her students into prestigious schools.</p>
            <p data-aos="fade-up" data-aos-delay="200">Gigi received her Master of Arts in Behavioral Sciences from
                California State University, Dominguez Hills and enjoys attending college admissions workshops and
                visiting colleges and universities across the country.</p>
        </div>
    </div>
</section>

<!-- Key Achievements Section -->
<section class="py-5 bg-white">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <h2 class="display-6 display-enhanced">Key Achievements</h2>
        </div>
        <div class="row row-cols-1 row-cols-md-2 g-4" data-aos="fade-up" data-aos-delay="100">
            <div class="col">
                <div class="stats-card enhanced-card h-100 p-4">
                    <div class="d-flex align-items-start gap-4">
                        <div class="orange-bg rounded-circle d-flex justify-content-center align-items-center flex-shrink-0 icon-enhanced float-animation"
                            style="width: 48px; height: 48px;">
                            <i class="bi bi-mortarboard-fill text-white fs-4"></i>
                        </div>
                        <div>
                            <h3 class="fs-5 fw-bold mb-2 orange-text">Master of Arts in Behavioral Sciences</h3>
                            <p class="text-secondary mb-0">California State University, Dominguez Hills</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="stats-card enhanced-card h-100 p-4">
                    <div class="d-flex align-items-start gap-4">
                        <div class="orange-bg rounded-circle d-flex justify-content-center align-items-center flex-shrink-0 icon-enhanced float-animation"
                            style="width: 48px; height: 48px; animation-delay: 0.5s;">
                            <i class="bi bi-award-fill text-white fs-4"></i>
                        </div>
                        <div>
                            <h3 class="fs-5 fw-bold mb-2 orange-text">Professional Memberships</h3>
                            <p class="text-secondary mb-0">Independent Educational Consultants Association (IECA)
                                and National Association for College Admission Counseling (NACAC)</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="stats-card enhanced-card h-100 p-4">
                    <div class="d-flex align-items-start gap-4">
                        <div class="orange-bg rounded-circle d-flex justify-content-center align-items-center flex-shrink-0 icon-enhanced float-animation"
                            style="width: 48px; height: 48px; animation-delay: 1s;">
                            <i class="bi bi-people-fill text-white fs-4"></i>
                        </div>
                        <div>
                            <h3 class="fs-5 fw-bold mb-2 orange-text">Founded College Connect 101</h3>
                            <p class="text-secondary mb-0">Established in 2010 with mission to help families
                                overcome college affordability challenges</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="stats-card enhanced-card h-100 p-4">
                    <div class="d-flex align-items-start gap-4">
                        <div class="orange-bg rounded-circle d-flex justify-content-center align-items-center flex-shrink-0 icon-enhanced float-animation"
                            style="width: 48px; height: 48px; animation-delay: 1.5s;">
                            <i class="bi bi-bullseye text-white fs-4"></i>
                        </div>
                        <div>
                            <h3 class="fs-5 fw-bold mb-2 orange-text">Debt-Free Success</h3>
                            <p class="text-secondary mb-0">Helped her daughter graduate from Loyola Marymount
                                University without any student debt</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Areas of Expertise Section -->
<section class="py-5 section-gradient-1">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="display-6 display-enhanced">Areas of Expertise</h2>
            <p class="lead text-secondary">Gigi's comprehensive knowledge spans multiple aspects of college planning
            </p>
        </div>
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <div class="col" data-aos="fade-up" data-aos-delay="100">
                <div class="service-card enhanced-card h-100 text-center">
                    <div class="card-body p-4">
                        <div class="orange-bg rounded-circle d-flex justify-content-center align-items-center mx-auto mb-4 icon-enhanced"
                            style="width: 50px; height: 50px;">
                            <i class="bi bi-compass text-white fs-5"></i>
                        </div>
                        <h3 class="fs-6 fw-bold mb-0 orange-text">College Application Process Navigation</h3>
                    </div>
                </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="200">
                <div class="service-card enhanced-card h-100 text-center">
                    <div class="card-body p-4">
                        <div class="orange-bg rounded-circle d-flex justify-content-center align-items-center mx-auto mb-4 icon-enhanced"
                            style="width: 50px; height: 50px;">
                            <i class="bi bi-cash-stack text-white fs-5"></i>
                        </div>
                        <h3 class="fs-6 fw-bold mb-0 orange-text">Financial Aid Maximization Strategies</h3>
                    </div>
                </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="300">
                <div class="service-card enhanced-card h-100 text-center">
                    <div class="card-body p-4">
                        <div class="orange-bg rounded-circle d-flex justify-content-center align-items-center mx-auto mb-4 icon-enhanced"
                            style="width: 50px; height: 50px;">
                            <i class="bi bi-patch-check text-white fs-5"></i>
                        </div>
                        <h3 class="fs-6 fw-bold mb-0 orange-text">Best Practices from IECA and NACAC</h3>
                    </div>
                </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="100">
                <div class="service-card enhanced-card h-100 text-center">
                    <div class="card-body p-4">
                        <div class="orange-bg rounded-circle d-flex justify-content-center align-items-center mx-auto mb-4 icon-enhanced"
                            style="width: 50px; height: 50px;">
                            <i class="bi bi-graph-up-arrow text-white fs-5"></i>
                        </div>
                        <h3 class="fs-6 fw-bold mb-0 orange-text">Merit Aid Package Negotiation</h3>
                    </div>
                </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="200">
                <div class="service-card enhanced-card h-100 text-center">
                    <div class="card-body p-4">
                        <div class="orange-bg rounded-circle d-flex justify-content-center align-items-center mx-auto mb-4 icon-enhanced"
                            style="width: 50px; height: 50px;">
                            <i class="bi bi-list-check text-white fs-5"></i>
                        </div>
                        <h3 class="fs-6 fw-bold mb-0 orange-text">Strategic College List Development</h3>
                    </div>
                </div>
            </div>
            <div class="col" data-aos="fade-up" data-aos-delay="300">
                <div class="service-card enhanced-card h-100 text-center">
                    <div class="card-body p-4">
                        <div class="orange-bg rounded-circle d-flex justify-content-center align-items-center mx-auto mb-4 icon-enhanced"
                            style="width: 50px; height: 50px;">
                            <i class="bi bi-pen text-white fs-5"></i>
                        </div>
                        <h3 class="fs-6 fw-bold mb-0 orange-text">Essay Coaching and Application Support</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Mission Section -->
<section class="py-5 bg-white">
    <div class="container text-center" style="max-width: 1000px;">
        <div class="mb-4" data-aos="zoom-in">
            <i class="bi bi-heart-fill display-4 orange-text float-animation"></i>
            <h2 class="display-6 display-enhanced mt-3" data-aos="fade-up" data-aos-delay="100">Gigi's Mission</h2>
        </div>
        <div class="mission-quote">
            <blockquote class="blockquote fs-4 text-secondary fst-italic mb-4">
                My mission is to ensure that every family I work with feels empowered and confident throughout the
                college admission process. Having experienced the challenges firsthand, I'm committed to providing
                the guidance, support, and expertise needed to help students achieve their dreams while managing the
                financial aspects responsibly.
            </blockquote>
            <figcaption class="blockquote-footer fs-6 orange-text fw-bold">
                Gigi Frye, Founder & CEO
            </figcaption>
        </div>
    </div>
</section>

<!-- Call to Action Section -->
<section class="contact-section text-center" data-aos="fade-up">
    <div class="container">
        <h2 class="orange-text" style="font-size: 1.875rem; font-weight: 700; margin-bottom: 1.5rem;">Need Help
            Scheduling?</h2>
        <p style="font-size: 1.125rem; color: var(--gray-700); margin-bottom: 2rem;">
            If you have any questions or need assistance, don't hesitate to contact us directly.
        </p>
        <div class="contact-buttons">
            <a href="tel:4248002248" class="contact-button">
                <svg class="lucide-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path
                        d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-4.71-4.71A19.79 19.79 0 0 1 2 4.18 2 2 0 0 1 4.18 2h3a2 2 0 0 1 2 2.18 15.28 15.28 0 0 0 .79 4.45 2 2 0 0 1-1.25 2.12c-.17.1-.34.2-.5.31A19.53 19.53 0 0 0 10 16.5a19.53 19.53 0 0 0 4.16-2.58c.11-.16.21-.33.31-.5a2 2 0 0 1 2.12-1.25z" />
                </svg>
                Call (424) 800-2248
            </a>
            <a href="#" class="contact-button">
                <svg class="lucide-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect width="20" height="16" x="2" y="4" rx="2" />
                    <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                </svg>
                Email Us
            </a>
        </div>
    </div>
</section>
@endsection