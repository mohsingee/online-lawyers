@extends('frontend.layouts.master')
@section('content')
 <!-- Hero Section Start -->
<section class="hero-section bg-light">
    <div class="container text-center">
    <h1 class="display-4 fw-bold mb-3 text-capitalize">
        <span class="orange-text">Terms and</span> conditions
    </h1>
    <p class="lead mb-0">
        Please read our terms and conditions carefully before using our
        services.
    </p>
    </div>
</section>
<!-- Hero Section End -->

<!-- Terms and Conditions Section Start -->
<section class="container py-5" id="terms-conditions">
    <div class="row justify-content-center">
    <div class="col-lg-10">
        <h1 class="mb-4 text-center d-none">Terms and Conditions</h1>
        <p class="fw-bold">
        NOTE: All sales are final, and NO refunds will be given after
        purchase. By purchasing our services, you agree to our terms and
        conditions.
        </p>
        <p>
        Pursuant to U.S. State & Federal Laws the following is a statement
        of your legal rights regarding sites operated by College Connect
        101, Inc.
        </p>
        <p>
        <strong>COLLEGE CONNECT 101, INC.</strong>, nor its partners,
        principals, consultants, represent that the student will gain
        admission to any particular college or university and neither
        COLLEGE CONNECT 101, INC., nor its partners, principals, consultants
        is responsible in any way for the student’s failure to gain such
        admission. Due to the ever-increasing number of applicants and the
        declining number of admits, no student can be assured of admission
        at any particular college or university, no matter how strong that
        student is academically. COLLEGE CONNECT 101, INC. specializes in
        helping students present their “best side” to universities and, as
        such, the student is able to maximize his/her chances for admission.
        COLLEGE CONNECT 101, INC. does not make any express or implied
        warranties, guarantees, assurances or representations to the Client
        with respect to the Services. Without limiting the foregoing, any
        implied warranty or condition is expressly excluded and disclaimed.
        </p>
        <h2 class="mt-5 h4">No Warranties</h2>
        <p>
        OUR WEBSITE AND SERVICES ARE PROVIDED, AS IS, WITHOUT WARRANTY OF
        ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
        THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
        PARTICULAR PURPOSE. OUR COMPANY DOES NOT WARRANT, GUARANTEE, OR MAKE
        ANY REPRESENTATIONS REGARDING THE USE, OR THE RESULTS OF THE USE, OF
        OUR WEBSITE AND SERVICES OR WRITTEN MATERIALS IN THE TERMS OF
        CORRECTNESS, ACCURACY, RELIABILITY, CURRENTNESS OR OTHERWISE. THE
        ENTIRE RISK AS TO THE RESULTS AND PERFORMANCE OF OUR WEBSITE AND
        SERVICES ARE ASSUMED BY YOU. IF OUR WEBSITE AND SERVICES OR WRITTEN
        MATERIALS ARE DEFECTIVE, YOU, AND NOT OUR COMPANY, ASSUME THE ENTIRE
        COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
        </p>
        <p>
        THIS IS THE ONLY WARRANT OF ANY KIND, EITHER EXPRESS OR IMPLIED,
        THAT IS MADE BY OUR COMPANY. NO ORAL OR WRITTEN INFORMATION OR
        ADVICE GIVEN BY OUR COMPANY SHALL CREATE A WARRANTY OR IN ANY WAY
        INCREASE THE SCOPE OF THIS WARRANTY, AND YOU MAY NOT RELY ON SUCH
        INFORMATION OR ADVICE TO DO SO.
        </p>
        <h2 class="mt-5 h4">Limitation & Exclusion Of Liability</h2>
        <p>
        These warranties exclude all incidental or consequential damages.
        Our company, and its suppliers, will not be liable for any damages
        whatsoever, including without limitation, damages for loss of
        business profits, business interruption, loss of business
        information, or other pecuniary loss. Some states do not allow the
        exclusion or limitation of liability, so the above limitations may
        not apply to you.
        </p>
        <h2 class="mt-5 h4">
        Legal Forum, Choice Of Laws & Official Language
        </h2>
        <p>
        Any from offering from College Connect 101, Inc., is a contract
        between you the buyer and our business, the seller. By electing to
        participate in this offer, you are entering into a contract.
        </p>
        <p>
        This Agreement shall be governed by and construed in accordance with
        the law, without regard to its conflict of laws rules. Any legal
        action arising out of this Agreement shall be litigated and enforced
        under the laws of the State of California. In addition, you agree to
        submit to the jurisdiction of the courts of the State of California,
        and that any legal action pursued by you shall be within the
        exclusive jurisdiction of the courts of Los Angeles County in the
        State of California, USA.
        </p>
        <p>
        The terms constituting this offering are set forth in writing on
        this Web site. You hereby agree to submit to the jurisdiction of the
        State and Federal Courts located in Los Angeles County, California,
        U.S.A. to resolve any disputes or litigation hereunder. Whether or
        not you choose to print this offering, containing the terms and
        conditions as described herein, you agree that this contract
        constitutes a writing.
        </p>
        <p>
        This agreement is being written in English, which is to be the
        official language of the contract’s text and interpretation. If you
        do not agree with the above terms and conditions, you have the
        option to not participate in this offer.
        </p>
        <p>Our company reserves all rights not expressly granted here.</p>
    </div>
    </div>
</section>
<!-- Terms and Conditions Section End -->
@endsection