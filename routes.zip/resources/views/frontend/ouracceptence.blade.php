@extends('frontend.layouts.master')
@push('css')
<style>       
    .fade-in {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease-out, transform 0.6s ease-out;
    }

    .fade-in.is-visible {
        opacity: 1;
        transform: translateY(0);
    }
</style>
@endpush
@section('content')
<div class="min-vh-100 bg-white">
    <!-- Hero Section -->
    <section class="hero-section ">
        <div class="container text-center fade-in ">
            <h1 class="">Our <span class="orange-text">Acceptances</span></h1>
            <p>
                Our students have been accepted to hundreds of prestigious colleges and universities
                across the United States and internationally.
            </p>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="py-5 bg-white">
        <div class="container fade-in">
            <div class="row row-cols-1 row-cols-md-3  text-center">
                <div class="col">
                    <div class="card h-100  enhanced-card border-0 shadow-sm hover-scale bg-light-orange">
                        <div class="card-body p-4 d-flex flex-column align-items-center">
                            <div class="p-3 mb-3 rounded-circle d-flex align-items-center justify-content-center bg-primary-orange"
                                style="width: 64px; height: 64px;">
                                <i class="bi bi-mortarboard-fill text-white fs-3"></i>
                            </div>
                            <h3 class="fs-4">95%</h3>
                            <p class="text-muted">Students accepted to their top 3 choices</p>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card h-100  enhanced-card border-0 shadow-sm hover-scale bg-light-orange">
                        <div class="card-body p-4 d-flex flex-column align-items-center">
                            <div class="p-3 mb-3 rounded-circle d-flex align-items-center justify-content-center bg-primary-orange"
                                style="width: 64px; height: 64px;">
                                <i class="bi bi-geo-alt-fill text-white fs-3"></i>
                            </div>
                            <h3 class="fs-4">40+</h3>
                            <p class="text-muted">States and international locations</p>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card enhanced-card h-100 border-0 shadow-sm hover-scale bg-light-orange">
                        <div class="card-body p-4 d-flex flex-column align-items-center">
                            <div class="p-3 mb-3 rounded-circle d-flex align-items-center justify-content-center bg-primary-orange"
                                style="width: 64px; height: 64px;">
                                <i class="bi bi-award-fill text-white fs-3"></i>
                            </div>
                            <h3 class="fs-4">500+</h3>
                            <p class="text-muted">College acceptances achieved</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Content Section -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5 fade-in">
                <h2 class="display-6 text-primary-orange">Our College Acceptances</h2>
                <p class="fs-5 text-muted">Explore where our students have been accepted</p>
                <div class="position-relative mx-auto mt-4" style="max-width: 500px;">
                    <i class="bi bi-search search-icon"></i>
                    <input type="text" class="form-control rounded-pill ps-5 pe-5 py-3 shadow-sm" id="searchInput"
                        placeholder="Search colleges or states...">
                    <button class="btn clear-search-btn" id="clearSearchBtn" style="display: none;"><i
                            class="bi bi-x fs-4"></i></button>
                </div>
                <div id="search-results-info" class="mt-2 text-muted small"></div>
            </div>

            <!-- Mobile Filter Bar - Becomes sticky on scroll -->
            <div id="mobile-filter-bar" class="d-lg-none">
                <div class="container">
                    <button class="btn btn-primary-orange w-100" data-bs-toggle="modal"
                        data-bs-target="#filterModal">
                        <i class="
                            bi-funnel-fill me-2"></i>
                        <span id="active-filter-text">Filter: Acceptances by State</span>
                    </button>
                </div>
            </div>


            <div class="row ">
                <!-- Sidebar Navigation (Desktop) -->
                <div class="col-lg-3 d-none d-lg-block">
                    <div class="card border-0 shadow-sm sticky-top" style="top: 120px;">
                        <div class="card-body p-4 card-bg-orange">
                            <h3 class="fs-5 mb-4 text-primary-orange">View Options</h3>
                            <div class="d-grid gap-3">
                                <button class="btn btn-outline-primary-orange text-start" id="byStateBtn"
                                    data-section="by-state">
                                    <i class="bi bi-geo-alt-fill me-2"></i> Acceptances by State
                                </button>
                                <button class="btn btn-outline-primary-orange text-start" id="prestigiousBtn"
                                    data-section="prestigious">
                                    <i class="bi bi-award-fill me-2"></i> Featured Prestigious
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Content Area -->
                <div class="col-12 col-lg-9">
                    <div id="content-area">
                        <!-- Dynamic content will be injected here -->
                    </div>
                </div>
            </div>
        </div>
    </section>

        <!-- Call to Action Section -->
<section class="contact-section text-center">
    <div class="container"  >
        <h2 class="orange-text" style="font-size: 1.875rem; font-weight: 700; margin-bottom: 1.5rem;">Need Help Scheduling?</h2>
        <p style="font-size: 1.125rem; color: var(--gray-700); margin-bottom: 2rem;">
            If you have any questions or need assistance, don't hesitate to contact us directly.
        </p>
        <div class="contact-buttons" >
            <a href="tel:4248002248" class="contact-button">
                <svg class="lucide-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-4.71-4.71A19.79 19.79 0 0 1 2 4.18 2 2 0 0 1 4.18 2h3a2 2 0 0 1 2 2.18 15.28 15.28 0 0 0 .79 4.45 2 2 0 0 1-1.25 2.12c-.17.1-.34.2-.5.31A19.53 19.53 0 0 0 10 16.5a19.53 19.53 0 0 0 4.16-2.58c.11-.16.21-.33.31-.5a2 2 0 0 1 2.12-1.25z"/></svg>
                Call (424) 800-2248
            </a>
            <a href="#" class="contact-button">
                    <svg class="lucide-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                Email Us
            </a>
        </div>
    </div>
</section>
@endsection