@extends('frontend.layouts.master')
@section('css)
 <style>
    .contact-card {
      transition: box-shadow 0.3s ease-in-out;
    }
    .contact-card:hover {
      box-shadow: 0 0.75rem 1.5rem rgba(0, 0, 0, 0.15);
    }
    .faq-content {
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.4s ease-in-out;
    }
    .faq-content.open {
      max-height: 500px;
    }
    .faq-icon {
      transition: transform 0.3s ease-in-out;
    }
    .faq-icon.rotate {
      transform: rotate(180deg);
    }
  </style>
@endsection
@section('content')
<!-- Hero -->
  <section class="hero-section">
    <div class="container text-center" data-aos="fade-up">
      <h1 data-aos="fade-up" data-aos-delay="100">
        Contact
        <span class="orange-text">Us</span> 
      </h1>
      <p data-aos="fade-up" data-aos-delay="200">
        Ready to start your college planning journey? Get in touch with our expert team today.
      </p>
    </div>
</section>


  <!-- Contact Info & Form -->
  <section class="py-5">
    <div class="container">
      <div class="row g-5">
        <!-- Contact Information -->
        <div class="col-lg-6" data-aos="fade-right" data-aos-delay="100">
          <h2 class="h2 mb-4 text-orange" data-aos="fade-up">Get in Touch</h2>
          <p class="text-muted mb-5" data-aos="fade-up" data-aos-delay="50">
            We're here to help you navigate the college admission process. Reach out to us using any of the methods below, and we'll get back to you promptly.
          </p>

          <!-- Cards -->
          <div class="mb-4 p-4 border rounded-3 shadow-sm contact-card" data-aos="fade-up" data-aos-delay="100">
            <div class="d-flex align-items-start">
              <div class="bg-orange rounded-circle d-flex align-items-center justify-content-center me-3"
                style="background-color: #e18552; width: 50px; height: 50px;">
                <i class="bi bi-geo-alt text-white fs-5"></i>
              </div>
              <div>
                <h5>Our Office</h5>
                <p class="mb-0">1626 Centinela Avenue, Suite 202</p>
                <p class="mb-0">Inglewood, CA. 90302</p>
              </div>
            </div>
          </div>

          <div class="mb-4 p-4 border rounded-3 shadow-sm contact-card">
            <div class="d-flex align-items-start">
              <div class="bg-orange rounded-circle d-flex align-items-center justify-content-center me-3"
                style="background-color: #e18552; width: 50px; height: 50px;">
                <i class="bi bi-telephone text-white fs-5"></i>
              </div>
              <div>
                <h5>Phone</h5>
                <a href="tel:424-800-2248" class="text-decoration-none text-muted">(424) 800-2248</a>
              </div>
            </div>
          </div>

          <div class="mb-4 p-4 border rounded-3 shadow-sm contact-card">
            <div class="d-flex align-items-start">
              <div class="bg-orange rounded-circle d-flex align-items-center justify-content-center me-3"
                style="background-color: #e18552; width: 50px; height: 50px;">
                <i class="bi bi-envelope text-white fs-5"></i>
              </div>
              <div>
                <h5>Email</h5>
                <a href="mailto:info@collegeconnect101.com" class="text-decoration-none text-muted">info@collegeconnect101.com</a>
              </div>
            </div>
          </div>

          <div class="mb-4 p-4 border rounded-3 shadow-sm contact-card">
            <div class="d-flex align-items-start">
              <div class="bg-orange rounded-circle d-flex align-items-center justify-content-center me-3"
                style="background-color: #e18552; width: 50px; height: 50px;">
                <i class="bi bi-clock text-white fs-5"></i>
              </div>
              <div>
                <h5>Office Hours</h5>
                <p class="mb-0">Mon - Fri: 9:00 AM - 6:00 PM</p>
                <p class="mb-0">Sat: 10:00 AM - 4:00 PM</p>
                <p class="mb-0">Sun: By Appointment Only</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Contact Form -->
        <div class="col-lg-6" data-aos="fade-left" data-aos-delay="100">
          <div class="p-4 border rounded-3 shadow-lg">
            <h3 class="h4 mb-2 text-orange">Send us a Message</h3>
            <p class="text-muted">Fill out the form below and we'll get back to you within 24 hours.</p>
            <form>
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label">First Name *</label>
                  <input type="text" class="form-control" required placeholder="Enter your first name">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Last Name *</label>
                  <input type="text" class="form-control" required placeholder="Enter your last name">
                </div>
                <div class="col-12">
                  <label class="form-label">Email *</label>
                  <input type="email" class="form-control" required placeholder="Enter your email">
                </div>
                <div class="col-12">
                  <label class="form-label">Phone</label>
                  <input type="tel" class="form-control" placeholder="Enter your phone number">
                </div>
                
                <div class="col-12">
                  <label class="form-label">Message *</label>
                  <textarea class="form-control" rows="5" required placeholder="Tell us about your college planning needs..."></textarea>
                </div>
              </div>
              <button type="submit" class="btn btn-orange w-100 mt-3">
                <i class="bi bi-send me-2"></i> Send Message
              </button>
              <p class="text-center text-muted small mt-2">
                * Required fields. We respect your privacy.
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Map -->
  <section class="py-5 bg-light">
  <div class="container text-center">
    <h2 class="h2 text-orange mb-3">Visit Our Office</h2>
    <p class="text-muted">We're conveniently located in Inglewood, California</p>
    <div class="border rounded-3 shadow-sm">

      <!-- Google Maps Embed -->
      <div class="mb-0 ">
        <iframe 
          src="https://www.google.com/maps?q=6826+S+La+Cienega+Blvd,+Inglewood,+CA+90302&output=embed" 
          width="100%" 
          height="400" 
          style="border:0;  " 
          allowfullscreen="" 
          loading="lazy" 
          referrerpolicy="no-referrer-when-downgrade">
        </iframe>
      </div>
    </div>
  </div>
</section>


  <!-- FAQ -->
  <!-- FAQ -->
<section class="py-5">
  <div class="container">
    <h2 class="h2 text-center mb-5 text-orange" data-aos="fade-up">Frequently Asked Questions</h2>
    <div class="accordion" id="faqAccordion">

      <div class="accordion-item" data-aos="fade-up" data-aos-delay="100">
        <h2 class="accordion-header" id="heading1">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq1"
            aria-expanded="false" aria-controls="faq1">
            How quickly can I expect a response?
          </button>
        </h2>
        <div id="faq1" class="accordion-collapse collapse" aria-labelledby="heading1" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            We typically respond to all inquiries within 24 hours during business days. For urgent matters, please call us directly.
          </div>
        </div>
      </div>

      <div class="accordion-item" data-aos="fade-up" data-aos-delay="100">
        <h2 class="accordion-header" id="heading2">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2"
            aria-expanded="false" aria-controls="faq2">
            Do you offer virtual consultations?
          </button>
        </h2>
        <div id="faq2" class="accordion-collapse collapse" aria-labelledby="heading2" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            Yes! We offer both in-person and virtual consultations to accommodate families regardless of their location.
          </div>
        </div>
      </div>

      <div class="accordion-item" data-aos="fade-up" data-aos-delay="100">
        <h2 class="accordion-header" id="heading3">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3"
            aria-expanded="false" aria-controls="faq3">
            What should I bring to my first consultation?
          </button>
        </h2>
        <div id="faq3" class="accordion-collapse collapse" aria-labelledby="heading3" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            Please bring your student's transcripts, test scores, list of extracurricular activities, and any college preferences or questions you may have.
          </div>
        </div>
      </div>

      <div class="accordion-item" data-aos="fade-up" data-aos-delay="100">
        <h2 class="accordion-header" id="heading4">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4"
            aria-expanded="false" aria-controls="faq4">
            When should we start the college planning process?
          </button>
        </h2>
        <div id="faq4" class="accordion-collapse collapse" aria-labelledby="heading4" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            Ideally, we recommend starting during your student's sophomore year of high school. However, we work with students at any stage.
          </div>
        </div>
      </div>

      <div class="accordion-item" data-aos="fade-up" data-aos-delay="100">
        <h2 class="accordion-header" id="heading5">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq5"
            aria-expanded="false" aria-controls="faq5">
            What is included in your comprehensive package?
          </button>
        </h2>
        <div id="faq5" class="accordion-collapse collapse" aria-labelledby="heading5" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            Our comprehensive package includes test prep, essay coaching, application assistance, financial aid guidance, and ongoing support.
          </div>
        </div>
      </div>

      <div class="accordion-item" data-aos="fade-up" data-aos-delay="100">
        <h2 class="accordion-header" id="heading6">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq6"
            aria-expanded="false" aria-controls="faq6">
            Do you guarantee college acceptances?
          </button>
        </h2>
        <div id="faq6" class="accordion-collapse collapse" aria-labelledby="heading6" data-bs-parent="#faqAccordion">
          <div class="accordion-body">
            While we cannot guarantee specific acceptances, 95% of our students are accepted to one of their top 3 schools.
          </div>
        </div>
      </div>

    </div>
  </div>
</section>


  <!-- Call to Action Section -->
     <!-- Call to Action Section -->
  <section class="contact-section text-center" data-aos="fade-up">
    <div class="container">
        <h2 class="orange-text" style="font-size: 1.875rem; font-weight: 700; margin-bottom: 1.5rem;">Need Help
            Scheduling?</h2>
        <p style="font-size: 1.125rem; color: var(--gray-700); margin-bottom: 2rem;">
            If you have any questions or need assistance, don't hesitate to contact us directly.
        </p>
        <div class="contact-buttons">
            <a href="tel:4248002248" class="contact-button">
                <svg class="lucide-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path
                        d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-4.71-4.71A19.79 19.79 0 0 1 2 4.18 2 2 0 0 1 4.18 2h3a2 2 0 0 1 2 2.18 15.28 15.28 0 0 0 .79 4.45 2 2 0 0 1-1.25 2.12c-.17.1-.34.2-.5.31A19.53 19.53 0 0 0 10 16.5a19.53 19.53 0 0 0 4.16-2.58c.11-.16.21-.33.31-.5a2 2 0 0 1 2.12-1.25z" />
                </svg>
                Call (424) 800-2248
            </a>
            <a href="#" class="contact-button">
                <svg class="lucide-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect width="20" height="16" x="2" y="4" rx="2" />
                    <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                </svg>
                Email Us
            </a>
        </div>
    </div>
</section>
@endsection
@section('js')
<script>
    document.querySelectorAll('.accordion-button').forEach(button => {
        button.addEventListener('click', () => {
          const icon = button.querySelector('.faq-icon');
          if (icon) {
            icon.classList.toggle('rotate');
          }
      });
    });
  </script>
@endsection