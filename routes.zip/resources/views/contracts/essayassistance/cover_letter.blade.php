<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Essay Assistance Package - College Connect 101</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&family=Teko:wght@500;600&family=Playfair+Display:wght@700&display=swap"
      rel="stylesheet"
    />
    <style>
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      body {
        font-family: "Inter", sans-serif;
        background-color: #f3f4f6;
        font-size:15px;
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        padding: 1rem;
      }

      .container {
        width: 100%;
        max-width: 56rem;
        background-color: white;
        border-radius: 0.5rem;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1),
          0 10px 10px -5px rgba(0, 0, 0, 0.04);
        overflow: hidden;
      }

      .header {
        position: relative;
      }

      .header-image {
        width: 100%;
        height: 22rem;
        object-fit: cover;
      }

      .logo-container {
        position: absolute;
        bottom: -4rem;
        right: 2rem;
        width: 8rem;
        height: 8rem;
        background-color: white;
        border-radius: 102%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        overflow: hidden;
      }

      .logo {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 50%;
      }

      .content {
        padding: 3rem;
        margin-top: 2rem;
      }

      h1 {
        font-size: 1.2rem;
        font-weight: 700;
        color: #111827;
        margin-bottom: 1.5rem;
      }

      .greeting {
        font-size:15px;
        color: #374151;
        margin-bottom: 2rem;
      }

      .body-text {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
        color: #1f2937;
        line-height: 1.625;
      }

      .signature {
        margin-top: 2rem;
      }

      .signature .warmly {
        font-size:15px;
        color: #374151;
      }

      .signature .name {
        font-family: "Playfair Display", serif;
        font-size:15px;
        font-weight: 700;
        color: #111827;
        margin-top: 1rem;
      }

      .signature .title {
        font-size:15px;
        color: #4b5563;
        font-style: italic;
      }

      footer {
        background-color: white;
        color: #1f2937;
        margin-top:5px;
        padding: 2rem 3rem 2.5rem;
      }

      .footer-border {
        border-top: 8px solid #111827;
        width: 100%;
        margin-bottom: 1.5rem;
      }

      .footer-content {
        text-align: center;
        font-size:15px;
      }

      .footer-content p {
        margin-bottom: 0.25rem;
      }

      .footer-content .bold {
        font-weight: 700;
      }

      .footer-content a {
        text-decoration: underline;
        color: inherit;
      }

      .footer-content a:hover {
        color: #b91c1c;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="header">
        <img src="{{ public_path('assets/coverimg.png') }}" alt="" class="header-image" />
      </div>

      <div class="content">
        <h1>Welcome to the Essay Assistance Package</h1>

        <div class="greeting">
          <p>Dear {{$user->name}},</p>
        </div>

        <div class="body-text">
          <p>
            We are thrilled to welcome your family to College Connect 101! Your student has an incredible story
            to share, and we can
            ’t wait to help them bring it to life. Thank you for trusting us with this important
            part of their journey.
          </p>
          <p>
            With the Essay Assistance Package, your student will have unlimited support in crafting essays that
            reflect their authentic experiences and passions. From personal statements to supplemental essays,
            we
            ’ll ensure every word captures who they are and what they bring to a college campus.
          </p>
          <p>
            Parents often tell us this is where they feel the most relief—knowing their student is not alone in the
            writing process. You can feel confident that we will guide them with care, encouragement, and
            expertise
          </p>
        </div>

        <!-- Signature -->
        <div class="signature">
          <p class="warmly">Warmly,</p>
          <p class="name">Gigi M. Frye</p>
          <p class="title" style="margin-top:5px;">President/CEO</p>
        </div>
      </div>

      <!-- Footer Section -->
      <footer>
        <div class="footer-border"></div>
        <div class="footer-content">
          <p>
            <span class="bold">WEBSITE:
            <a href="https://www.collegeconnect101.com/"
              >WWW.COLLEGECONNECT101.COM</a></span>
          </p>
          <p>
            <span class="bold">ADDRESS: 1626 CENTINELA AVENUE INGLEWOOD,
            CA 90302</span>
          </p>
          <p>
            <span class="bold">FACEBOOK/INSTAGRAM: COLLEGE CONNECT 101</span>
            <span class="bold" style="margin-left: 0.5rem">PHONE:
            424-800-2248</span>
          </p>
        </div>
      </footer>
    </div>
  </body>
</html>
