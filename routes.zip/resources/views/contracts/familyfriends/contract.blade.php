<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Family and Friends Contract</title>
  <style>
    body{
      margin:0;
      padding:1rem;
      font-size:15px;
      font-family:Arial, Helvetica, sans-serif;
      line-height:1.6;
      background:#f5f6fa;
      color:#222;
      display:flex;
      justify-content:center;
    }
    .contract{
      background:#fff;
      padding:20px 30px;
      max-width:800px;
      border:1px solid #ddd;
      border-radius:8px;
      box-shadow:0 4px 20px rgba(0,0,0,0.08);
    }
    h1{
      font-size:20px;
      margin-bottom:20px;
      text-align:center;
      text-decoration:underline;
    }
    p{
      margin:6px 0;
    }
    ol{
      margin:15px 0;
      padding-left:22px;
    }
    li{
      margin:10px 0;
    }
    .choices{
      margin:12px 0 20px;
    }
    .choice{
      margin:6px 0;
      display:flex;
      align-items:center;
    }
    .box{
      width:16px;
      height:16px;
      border:1px solid #333;
      margin-right:10px;
      display:inline-block;
    }
    .notice{
      background:#fff4e6;
      padding:10px;
      border-left:4px solid #f39c12;
      border-radius:4px;
      margin:15px 0;
      font-size:15px;
    }
    .agreed{
      background:#e5f8d8;
      padding:10px;
      border-left:4px solid #9fda8d;
      border-radius:4px;
      margin:15px 0;
      font-size:15px;
    }
    .signatures{
      display:flex;
      justify-content:space-between;
      margin-top:40px;
      gap:20px;
    }
    .sign{
      flex:1;
    }
  </style>
</head>
<body>
  <div class="contract">
    <center><img src="{{ public_path('assets/logo.jpg') }}" alt="College Connect 101 Logo" width="140"></center>

    <p style="margin-top:6px;">This <strong>Consulting Agreement</strong> (the "Agreement") states the terms and conditions that govern the contractual agreement between <strong>College Connect 101</strong> (the "Company") and <strong>{{$user->name}}</strong> (the "Client").</p>

    <p><strong>WHEREAS</strong> the Company offers consulting services in the field of College Admission Advisory; and <strong>WHEREAS</strong>, the Client desires to retain the services of the Company to render consulting services with regard to the Family and Friends according to the terms and conditions herein.</p>

    <p><strong>NOW, THEREFORE</strong>, in consideration of the mutual covenants and promises made by the parties, the Company and the Client covenant and agree as follows:</p>

    <ol>
      <li>
        <strong>TERM.</strong> This agreement shall begin on <strong>{{date('d-m-Y')}}</strong> and continue until applications are submitted (unless otherwise agreed).
      </li>
      <li>
        <strong>CONSULTING SERVICES.</strong> The Company agrees to provide expertise to the Client for all things pertaining to the Family and Friends (the "Consulting Services").
      </li>
      <li>
        <strong>COMPENSATION.</strong> The flat fee for the Family and Friends is <strong>$6,500</strong>. Client agrees to select a payment plan below:
        <div class="choices">
          <div class="choice">One Payment of $6,500 due at signing</div>
          <div class="choice">Two Payments of $3,250 each (first due at signing, second due same day next month)</div>
        </div>
        <div class="agreed"><strong>Selected Plan</strong> You are selected <b>{{$plan->title}}</b> plan <b>${{$plan->price}}</b>.</div>
        <div class="notice"><strong>NO REFUNDS.</strong> All payments made under this Agreement are non-refundable once services have begun, regardless of whether the Client continues with the services or terminates early.</div>
      </li>
      <li>
        <strong>NONSOLICITATION OF EMPLOYEES.</strong> During the term of this Agreement, the Client will not recruit or solicit the Company's employees.
      </li>
      <li>
        <strong>NONDISCLOSURE OF CLIENT'S FINANCIAL EARNINGS.</strong> Company shall not disclose any financial earnings of the Client that fall outside of preparing financial aid documentation.
      </li>
      <li>
        <strong>APPLICABLE LAWS.</strong> This Agreement shall be governed by the laws of the State of California.
      </li>
    </ol>

    <p>IN WITNESS WHEREOF, the Parties have executed this Consulting Agreement.</p>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <div class="signatures">
      <div class="sign">
        <div><br>Sign: ______________________<br><br>Gigi M. Frye, President/CEO<br><br>Date: <u>{{date('d-m-Y')}}</u></div>
      </div>
      <div class="sign">
        <div> <br>Sign: ______________________<span style="color:transparent;display:inline-block; margin-left:-160px;margin-bottom:20px;">**signature**</span><br><br>{{$user->name}}<br><br>Date: <u>{{date('d-m-Y')}}</u></div>
      </div>
    </div>
  </div>
</body>
</html>
