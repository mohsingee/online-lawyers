<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\DocusignController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\User\UserController;
use App\Http\Controllers\Admin\UsersController;
use App\Http\Controllers\Admin\AdminPaymentController;
use App\Http\Controllers\Admin\PackageController;
use App\Http\Controllers\QuickBooksController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;

Auth::routes([
    'register' => false, 
    'verify' => true
]);

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/founder', [HomeController::class, 'founder'])->name('founder');
Route::get('/contactus', [HomeController::class, 'contactus'])->name('contactus');
Route::get('/collegeplanning', [HomeController::class, 'collegeplanning'])->name('collegeplanning');
Route::get('/ouracceptence', [HomeController::class, 'ouracceptence'])->name('ouracceptence');
Route::get('/appointement', [HomeController::class, 'appointement'])->name('appointement');
Route::get('/termconditions', [HomeController::class, 'termconditions'])->name('termconditions');


Route::middleware(['auth'])->group(function () {

    Route::get('dashboard',[HomeController::class,'dashboard'])->name('dashboard');
    Route::get('/profile', [HomeController::class, 'profile'])->name('profile');
    Route::post('/update-profile', [HomeController::class, 'updateProfile'])->name('account.update');

    Route::middleware('user')->group(function () {
        Route::get('/user-dashboard', [UserController::class, 'index'])->name('user.dashboard');
        Route::get('/user-contracts', [UserController::class, 'contracts'])->name('user.contracts');
        Route::post('/user-agreement', [DocusignController::class, 'signDocument'])->name('user.signAgreement');
    });

    Route::middleware('admin')->group(function () {
        Route::get('/admin-dashboard', [AdminController::class, 'index'])->name('admin.dashboard');
        Route::resource('users', UsersController::class);
        Route::get('/assigned-contracts', [PackageController::class,'index'])->name('package.assigned');
        Route::get('/choose-package/{id?}', [PackageController::class,'create'])->name('package.choose');
        Route::post('/pacakge-send', [PackageController::class,'store'])->name('package.send');
        Route::DELETE('/package-destroy/{id}', [PackageController::class,'destroy'])->name('package.destroy');

        Route::get('/payment-history', [AdminPaymentController::class,'index'])->name('payment.history');
        Route::get('payment/view/{subscription}', [AdminPaymentController::class, 'view'])->name('payment.view');
    });

    Route::get('docusign',[DocusignController::class, 'index'])->name('docusign');
    Route::get('connect-docusign',[DocusignController::class, 'connectDocusign'])->name('connect.docusign');
    Route::get('docusign/callback',[DocusignController::class,'callback'])->name('docusign.callback');

});

Route::get('/payment', [PaymentController::class, 'index'])->name('payment.index');
Route::post('/payment/process/{id}', [PaymentController::class, 'processFullPayment'])->name('payment.process');
Route::post('/payment/installment/{id}', [PaymentController::class, 'processInstallmentPayment'])->name('payment.installment');
Route::get('/payment/error', [PaymentController::class, 'paymentError'])->name('payment.error');
Route::get('/payment/cancel', [PaymentController::class, 'paymentCancel'])->name('payment.cancel');

Route::withoutMiddleware([VerifyCsrfToken::class])->group(function () {
    Route::post('/payment/response', [PaymentController::class, 'paymentResponse'])->name('payment.response');
    Route::post('/payment/notification', [PaymentController::class, 'elavonWebhook'])->name('payment.notification');
});

Route::get('/quickbooks/dashboard', [QuickBooksController::class, 'dashboard'])->name('quickbooks.dashboard');
Route::get('/quickbooks/connect', [QuickBooksController::class, 'connect'])->name('quickbooks.connect');
Route::get('/quickbooks/callback', [QuickBooksController::class, 'callback']);

Route::post('/quickbooks/check-customer', [QuickBooksController::class, 'checkCustomerByEmail']);
Route::post('/quickbooks/create-customer', [QuickBooksController::class, 'createCustomer']);
Route::post('/quickbooks/create-payment', [QuickBooksController::class, 'createPayment']);