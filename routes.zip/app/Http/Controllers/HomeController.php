<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use App\Models\User;

class HomeController extends Controller
{
    public function index(){
        return view('frontend.index');   
    }

    public function founder(){
        return view('frontend.founder');   
    }

    public function contactus(){
        return view('frontend.contactus');   
    }

    public function collegeplanning(){
        return view('frontend.collegeplanning');   
    }

    public function ouracceptence(){
        return view('frontend.ouracceptence');   
    }

    public function appointement(){
        return view('frontend.appointement');   
    }

    public function termconditions(){
        return view('frontend.termconditions');   
    }

    public function dashboard(){
        if (auth()->user()->role === 'admin') {
            return redirect(route('admin.dashboard'));
        }

        return redirect(route('user.dashboard'));
    }

    public function profile(){
        return view('profile');
    }

    public function updateProfile(Request $request){
        $user = auth()->user();
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:100',
            'email' => [
                'required',
                'email',
                Rule::unique('users', 'email')->ignore($user->id),
            ],
            'password' => 'nullable|min:6|confirmed',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors()
            ], 422);
        }

        $user->name = $request->name;
        $user->email = $request->email;

        if ($request->filled('password')) {
            $user->password = Hash::make($request->password);
        }

        $user->save();

        return response()->json([
            'message' => 'Profile updated successfully!'
        ]);
    }
}
