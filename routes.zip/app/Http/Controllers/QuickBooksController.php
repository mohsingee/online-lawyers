<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use QuickBooksOnline\API\DataService\DataService;
use QuickBooksOnline\API\Core\OAuth\OAuth2\OAuth2AccessToken;
use QuickBooksOnline\API\Facades\Payment;
use QuickBooksOnline\API\Facades\Invoice;
use QuickBooksOnline\API\Facades\Customer;
use App\Models\QuickbookToken;

class QuickBooksController extends Controller
{
    private $clientID;
    private $clientSecret;
    private $redirectURI;

    public function __construct(){
        $this->clientID     = 'ABWJHeySVW5DJorZCXtzUSZmUzVezWGSWNO5bGS5EDqm6wr9jt';
        $this->clientSecret = 'QWjaDCEVgxrNNfd9oGPIf12vo2HWICMns5eQGSc1';
        $this->redirectURI  = 'https://democollge.slmsafroasian.com/quickbooks/callback';
    }

    /**
     * Create configured DataService instance
     */
    private function getDataService($realmId = null, $accessToken = null){
        $config = [
            'auth_mode'    => 'oauth2',
            'ClientID'     => $this->clientID,
            'ClientSecret' => $this->clientSecret,
            'RedirectURI'  => $this->redirectURI,
            'scope'        => 'com.intuit.quickbooks.accounting',
            'baseUrl'      => 'development',
        ];

        if ($realmId) {
            $config['QBORealmID'] = $realmId;
        }

        $dataService = DataService::Configure($config);

        if ($accessToken) {
            $dataService->updateOAuth2Token($accessToken);
        }

        $dataService->setLogLocation(storage_path('logs/quickbooks.log'));
        $dataService->throwExceptionOnError(true);

        return $dataService;
    }

    /**
     * Token Database میں Store کریں
     */
    private function storeTokenInDatabase($accessTokenObj, $realmId){
        QuickbookToken::updateOrInsert(
            ['realm_id' => $realmId],
            [
                'access_token'  => $accessTokenObj->getAccessToken(),
                'refresh_token' => $accessTokenObj->getRefreshToken(),
                'expires_at'    => now()->addSeconds($accessTokenObj->getAccessTokenExpiresAt()),
                'created_at'    => now(),
                'updated_at'    => now(),
            ]
        );
    }

    /**
     * Step 1: Redirect user to QuickBooks authorization page
     */
    public function connect(){
        $dataService = $this->getDataService();
        $OAuth2LoginHelper = $dataService->getOAuth2LoginHelper();
        $authUrl = $OAuth2LoginHelper->getAuthorizationCodeURL();

        return redirect($authUrl);
    }

    /**
     * Step 2: Handle QuickBooks callback
     */
    public function callback(Request $request){
        $realmId = $request->input('realmId');

        $dataService = $this->getDataService();
        $OAuth2LoginHelper = $dataService->getOAuth2LoginHelper();

        $accessTokenObj = $OAuth2LoginHelper->exchangeAuthorizationCodeForToken($request->code, $realmId);

        if (!$accessTokenObj) {
            return response()->json(['error' => 'Failed to get access token from QuickBooks.'], 400);
        }

        // ✅ Database میں token store کریں
        $this->storeTokenInDatabase($accessTokenObj, $realmId);

        // ✅ Session میں بھی store کریں
        session([
            'quickbooks_token' => serialize($accessTokenObj),
            'realmId' => $realmId,
        ]);

        return redirect()->route('quickbooks.dashboard');
    }

    /**
     * Dashboard - Connection
     */
    public function dashboard(){
        $token = QuickbookToken::latest()->first();
        $refreshedToken = $this->refreshAccessToken($token);
        if($refreshedToken == false){
            $connected = false;
            $connected = null;
        }

        return view('admin.pages.quickbooks.dashboard', [
            'connected' => $connected,
            'realmId' => $realmId
        ]);
    }

    /**
     * Check if customer exists by email
     */
    public function checkCustomerByEmail(Request $request){
        $email = $request->input('email');
        
        if (!$email) {
            return response()->json(['error' => 'Email is required'], 400);
        }

        $token = session('quickbooks_token');
        $realmId = session('realmId');

        if (!$token || !$realmId) {
            return response()->json(['error' => 'QuickBooks not connected.'], 401);
        }

        $accessToken = unserialize($token);
        $dataService = $this->getDataService($realmId, $accessToken);

        // Query customer by email
        $customers = $dataService->Query("SELECT * FROM Customer WHERE PrimaryEmailAddr = '{$email}'");

        if ($error = $dataService->getLastError()) {
            return response()->json(['error' => $error->getResponseBody()], 400);
        }

        if (!empty($customers) && count($customers) > 0) {
            $customer = $customers[0];
            return response()->json([
                'exists' => true,
                'customer' => [
                    'id' => $customer->Id,
                    'name' => $customer->DisplayName ?? '',
                    'email' => $customer->PrimaryEmailAddr ?? '',
                    'company' => $customer->CompanyName ?? ''
                ]
            ]);
        }

        return response()->json(['exists' => false]);
    }

    /**
     * Create new customer in QuickBooks
     */
    public function createCustomer(Request $request){
        $validated = $request->validate([
            'name' => 'required|string',
            'email' => 'required|email',
            'company' => 'nullable|string',
            'phone' => 'nullable|string',
            'address' => 'nullable|string'
        ]);

        $token = session('quickbooks_token');
        $realmId = session('realmId');

        if (!$token || !$realmId) {
            return response()->json(['error' => 'QuickBooks not connected.'], 401);
        }

        $accessToken = unserialize($token);
        $dataService = $this->getDataService($realmId, $accessToken);

        // First check if customer already exists
        $existingCustomers = $dataService->Query("SELECT * FROM Customer WHERE PrimaryEmailAddr = '{$validated['email']}'");
        
        if (!empty($existingCustomers) && count($existingCustomers) > 0) {
            $customer = $existingCustomers[0];
            return response()->json([
                'success' => false,
                'message' => 'Customer already exists with this email',
                'customer_id' => $customer->Id,
                'customer_name' => $customer->DisplayName
            ], 409); // Conflict status code
        }

        // Create new customer
        $customerData = [
            "DisplayName" => $validated['name'],
            "PrimaryEmailAddr" => [
                "Address" => $validated['email']
            ],
            "CompanyName" => $validated['company'] ?? $validated['name'],
        ];

        // Add optional fields if provided
        if ($request->has('phone')) {
            $customerData["PrimaryPhone"] = [
                "FreeFormNumber" => $validated['phone']
            ];
        }

        if ($request->has('address')) {
            $customerData["BillAddr"] = [
                "Line1" => $validated['address']
            ];
        }

        $customer = Customer::create($customerData);
        $result = $dataService->Add($customer);

        if ($error = $dataService->getLastError()) {
            \Log::error('QuickBooks Customer Creation Error', [
                'error' => $error->getResponseBody(),
                'customer_data' => $customerData
            ]);
            
            return response()->json(['error' => 'Customer creation failed: ' . $error->getResponseBody()], 400);
        }

        \Log::info('QuickBooks Customer Created', [
            'customer_id' => $result->Id,
            'customer_name' => $result->DisplayName,
            'email' => $result->PrimaryEmailAddr
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Customer created successfully!',
            'customer_id' => $result->Id,
            'customer_name' => $result->DisplayName
        ]);
    }

    /**
     * Create payment for specific customer
     */
    public function createPayment(Request $request){
        $validated = $request->validate([
            'customer_email' => 'required|email',
            'amount' => 'required|numeric|min:0.01',
            'payment_date' => 'required|date',
            'reference_no' => 'required|string',
            'invoice_id' => 'nullable|string'
        ]);

        $token = session('quickbooks_token');
        $realmId = session('realmId');

        if (!$token || !$realmId) {
            return response()->json(['error' => 'QuickBooks not connected.'], 401);
        }

        $accessToken = unserialize($token);
        $dataService = $this->getDataService($realmId, $accessToken);

        // Step 1: Check if customer exists
        $customers = $dataService->Query("SELECT * FROM Customer WHERE PrimaryEmailAddr = '{$validated['customer_email']}'");

        if ($error = $dataService->getLastError()) {
            return response()->json(['error' => 'Error checking customer: ' . $error->getResponseBody()], 400);
        }

        if (empty($customers)) {
            return response()->json([
                'success' => false,
                'message' => 'Customer not found with this email. Please create customer first.',
                'customer_email' => $validated['customer_email']
            ], 404);
        }

        $customer = $customers[0];
        $customerId = $customer->Id;
        $customerName = $customer->DisplayName;

        // Step 2: Create payment
        $paymentData = [
            "CustomerRef" => [
                "value" => $customerId,
                "name"  => $customerName
            ],
            "TotalAmt" => $validated['amount'],
            "TxnDate" => $validated['payment_date'],
            "PrivateNote" => "Payment received via Elavon. Ref: " . $validated['reference_no'],
        ];

        // Add invoice link if provided
        if ($request->has('invoice_id') && $validated['invoice_id']) {
            $paymentData["Line"] = [
                [
                    "Amount" => $validated['amount'],
                    "LinkedTxn" => [
                        [
                            "TxnId" => $validated['invoice_id'],
                            "TxnType" => "Invoice"
                        ]
                    ]
                ]
            ];
        }

        $payment = Payment::create($paymentData);
        $result = $dataService->Add($payment);

        if ($error = $dataService->getLastError()) {
            \Log::error('QuickBooks Payment Error', [
                'error' => $error->getResponseBody(),
                'payment_data' => $paymentData
            ]);
            
            return response()->json(['error' => 'Payment sync failed: ' . $error->getResponseBody()], 400);
        }

        \Log::info('QuickBooks Payment Successful', [
            'payment_id' => $result->Id,
            'amount' => $result->TotalAmt,
            'customer' => $customerName,
            'customer_email' => $validated['customer_email']
        ]);

        return response()->json([
            'success' => true, 
            'payment_id' => $result->Id,
            'amount' => $result->TotalAmt,
            'customer_name' => $customerName,
            'message' => 'Payment synced to QuickBooks successfully!'
        ]);
    }

    private function refreshAccessToken($tokenData){
        try {
            $dataService = $this->getDataService();
            $OAuth2LoginHelper = $dataService->getOAuth2LoginHelper();
            
            $newToken = $OAuth2LoginHelper->refreshAccessTokenWithRefreshToken($tokenData->refresh_token);
            
            QuickbookToken::where('realm_id', $tokenData->realm_id)
                ->update([
                    'access_token'  => $newToken->getAccessToken(),
                    'refresh_token' => $newToken->getRefreshToken(),
                    'expires_at'    => now()->addSeconds($newToken->getAccessTokenExpiresAt()),
                    'updated_at'    => now(),
                ]);
                
            return true;
        } catch (\Exception $e) {
            \Log::error('QuickBooks Token Refresh Failed: ' . $e->getMessage());
            return false;
        }
    }
}