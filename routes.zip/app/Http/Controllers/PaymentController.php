<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\UserSubscription;
use App\Models\UserPayment;
use App\Models\User;
use Carbon\Carbon;

class PaymentController extends Controller
{
    private $merchantId;
    private $userId;
    private $pin;
    private $apiUrl;
    private $hostedUrl;

    public function __construct(){
        $this->merchantId = "597012";
        $this->userId     = "webpage";
        $this->pin        = "YZ07P7D6ZYYMDJOHLEDYBHJO1OU5PXMEKCA4PG9KC6RU1LT1DPNT7W40NUCF50KK";
        $this->apiUrl     = "https://api.convergepay.com/VirtualMerchant/processxml.do";
        $this->hostedUrl  = "https://api.convergepay.com/hosted-payments";
    }

    public function index(){
        $user = User::where('email', 'mohsing523@gmail.com')->first();
        $subscription = UserSubscription::with(['user', 'package', 'plan', 'payments'])->where('user_id', $user->id)->latest()->first();
        $payments = $subscription->payments()->latest()->get();

        $nextBilling = $subscription ? (object)[
            'due_date' => $subscription->next_due_date,
            'amount'   => $subscription->installment_amount
        ] : null;

        return view('user.pages.payment.index', compact('user', 'payments', 'nextBilling', 'subscription'));
    }

    /** Create transaction token for full or recurring payment */
    private function createTransactionToken($amount, $invoiceId, $isRecurring = false){
        $data = [
            "ssl_merchant_id"      => $this->merchantId,
            "ssl_user_id"          => $this->userId,
            "ssl_pin"              => $this->pin,
            "ssl_transaction_type" => "ccsale",
            "ssl_amount"           => $amount,
            "ssl_currency_code"    => "USD",
            "ssl_test_mode"        => "false",
            "ssl_invoice_number"   => $invoiceId,
        ];

        if ($isRecurring) {
            $data["ssl_get_token"] = "Y";
            $data["ssl_add_token"] = "Y";
        }

        $res = Http::asForm()->timeout(30)->post("{$this->hostedUrl}/transaction_token", $data);
        if ($res->failed()) throw new \Exception('Gateway error: '.$res->status());
        $body = trim($res->body());

        if (preg_match('/ssl_txn_auth_token=([^&]+)/', $body, $m)) return $m[1];
        if (preg_match('/^[A-Za-z0-9+\/=]{20,}$/', $body)) return $body;

        Log::error('Token error: '.$body);
        throw new \Exception('Token generation failed.');
    }

    public function processFullPayment(Request $r){
        try {
            $sub = UserSubscription::findOrFail($r->id);
            if ($sub->subscription_type !== "full") return back()->with('error', 'Invalid payment type');
            $token = $this->createTransactionToken(2, $sub->id, false);
            return redirect()->away("{$this->hostedUrl}?ssl_txn_auth_token=" . urlencode($token));
        } catch (\Exception $e) {
            Log::error('Full Payment: '.$e->getMessage());
            return back()->with('error', $e->getMessage());
        }
    }

    public function processInstallmentPayment(Request $r){
        try {
            $sub = UserSubscription::findOrFail($r->id);
            if ($sub->subscription_type !== "installment") return back()->with('error', 'Invalid subscription');
            
            $token = $this->createTransactionToken(2, $sub->id, true);
            return redirect()->away("{$this->hostedUrl}?ssl_txn_auth_token=" . urlencode($token));
        } catch (\Exception $e) {
            Log::error('Installment: '.$e->getMessage());
            return back()->with('error', $e->getMessage());
        }
    }

    public function paymentResponse(Request $r) {
        $data = $r->all();
        Log::info('Payment Response Received:', $data);

        if (!isset($data['ssl_result']) || $data['ssl_result'] != '0') {
            Log::error('Payment failed response:', $data);
            return view('user.pages.payment.response', [
                'status' => 'error',
                'message' => 'Payment failed: ' . ($data['ssl_result_message'] ?? 'Unknown error'),
                'data' => $data
            ]);
        }

        DB::beginTransaction();
        try {
            $sub = UserSubscription::find($data['ssl_invoice_number']);
            if (!$sub) {
                throw new \Exception('Subscription not found.');
            }

            $user = User::where('email', 'mohsing523@gmail.com')->first();
            if (!$user) {
                throw new \Exception('User not found.');
            }

            $cardToken = $data['ssl_token'] ?? null;
            $isInstallment = $sub->subscription_type == "installment";

            // Save card token if available
            if ($cardToken && !empty($cardToken)) {
                $sub->update(['card_token' => $cardToken]);
                Log::info("Card token saved for subscription {$sub->id}");
            }

            $msg = "Payment successful!";
            $comment = "Payment";

            if ($isInstallment) {
                $newInstallmentsPaid = $sub->installments_paid + 1;
                
                if ($newInstallmentsPaid == 1) {
                    $comment = "First Installment";
                    $msg .= " Your subscription is now active.";
                    
                    $sub->update([
                        'installments_paid' => $newInstallmentsPaid,
                        'status' => 'active',
                        'start_date' => Carbon::now(),
                        'next_due_date' => Carbon::now()->addMonth(),
                        'end_date' => Carbon::now()->addMonths($sub->total_installments - 1)
                    ]);
                }
            } else {
                $sub->update(['status' => 'completed']);
                $comment = "Full Payment";
                $msg .= " Thank you for your payment!";
            }

            // Record payment
            UserPayment::create([
                'user_id' => $user->id,
                'subscription_id' => $sub->id,
                'txn_id' => $data['ssl_txn_id'] ?? null,
                'amount' => $data['ssl_amount'] ?? 0,
                'comment' => $comment
            ]);

            DB::commit();

            // Token message
            if ($isInstallment && $cardToken) {
                $msg .= " Future payments will be processed automatically.";
            }

            return view('user.pages.payment.response', [
                'status' => 'success',
                'message' => $msg,
                'data' => $data,
                'subscription' => $sub
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Payment response processing error: '.$e->getMessage());
            
            return view('user.pages.payment.response', [
                'status' => 'error',
                'message' => 'Error processing payment: ' . $e->getMessage(),
                'data' => $data
            ]);
        }
    }

    public function testTokenPayment(){
        $xml = '<txn>
                    <ssl_merchant_id>'.$this->merchantId.'</ssl_merchant_id>
                    <ssl_user_id>'.$this->userId.'</ssl_user_id>
                    <ssl_pin>'.$this->pin.'</ssl_pin>
                    <ssl_transaction_type>ccaddinstall</ssl_transaction_type>
                    <ssl_token>' . $sslToken . '</ssl_token>
                    <ssl_amount>2.00</ssl_amount>
                    <ssl_first_name>Gigi</ssl_first_name>
                    <ssl_last_name>Frye</ssl_last_name>
                    <ssl_avs_address>123 Test Street</ssl_avs_address>
                    <ssl_city>Los Angeles</ssl_city>
                    <ssl_state>CA</ssl_state>
                    <ssl_avs_zip>90001</ssl_avs_zip>
                    <ssl_billing_cycle>MONTHLY</ssl_billing_cycle>
                    <ssl_total_installments>1</ssl_total_installments>
                    <ssl_next_payment_date>' . now()->addMonth()->format('m/d/Y') . '</ssl_next_payment_date>
                    <boater_safety_id>'.uniqid().'</boater_safety_id>
                </txn>';

        $response = Http::asForm()->post($this->api, [
            'xmldata' => $xml,
        ]);

        Log::info('Recurring Payment Response:', ['response' => $response->body()]);

        return $response->body();
    }

    public function paymentError(){
        return redirect()->route('payment.index')->with('error', 'Payment Declined!');
    }

    public function paymentCancel(){
        return redirect()->route('payment.index')->with('error', 'Payment Canceled!');
    }
    
    public function elavonWebhook(Request $request){
        Log::info('Elavon webhook data:', $request->all());
    }
}