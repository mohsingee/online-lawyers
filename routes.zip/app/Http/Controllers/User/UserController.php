<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UserPackage;
use App\Models\UserAgreement;
use App\Models\UserSubscription;
use App\Models\UserPayment;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function index(){
        $userid = Auth::id();
        $totalAmount = UserSubscription::where('user_id', $userid)->sum('total_amount');

        $paidAmount = UserPayment::where('user_id', $userid)->sum('amount');

        $pendingAmount = $totalAmount - $paidAmount;

        $completedContract = UserSubscription::where('status','completed')->count();

        return view('user.pages.dashboard', compact(
            'totalAmount', 
            'paidAmount', 
            'pendingAmount', 
            'completedContract'
        ));
    }

    public function contracts(){
        $userId = Auth::id();

        $contracts = UserPackage::with('package.plans')
            ->where('user_id', $userId)
            ->get();

        $signedContract = UserAgreement::where('user_id', $userId)
            ->where('status', 'completed')
            ->with(['plan'])
            ->first();

        if ($contracts->isEmpty()) {
            return view('user.pages.contracts', [
                'contracts' => null,
                'message'   => 'You have not been assigned any contract yet.'
            ]);
        }

        return view('user.pages.contracts', compact('contracts','signedContract'));
    }

    public function agreement(Request $request){
        dd($request->all());
    }
}
