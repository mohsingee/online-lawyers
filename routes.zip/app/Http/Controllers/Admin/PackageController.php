<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\UserPackage;
use App\Models\Package;

class PackageController extends Controller
{
    public function index(){
        $users = User::with(['packages.package', 'payments', 'subscription'])->has('packages')->get();
        return view('admin.pages.contracts.index', compact('users'));
    }

    public function create($id=null){
        $users = User::where('role','user')->get();
        $packages = Package::with('plans')->get();
        return view('admin.pages.contracts.choosePackage',compact('users','packages','id'));
    }

    public function store(Request $request){
        $request->validate([
            'user_id' => 'required|exists:users,id',
            'mode'    => 'required|in:one,multi',
        ]);

        if ($request->mode === 'one') {
            $request->validate([
                'package_id' => 'required|exists:packages,id',
            ]);

            $packageId = $request->package_id;

            $exists = UserPackage::where('user_id', $request->user_id)
                        ->where('package_id', $packageId)
                        ->exists();

            if ($exists) {
                return response()->json([
                    'status'  => false,
                    'message' => 'You have already assigned this contract to the selected user!',
                ], 422);
            }

            UserPackage::create([
                'user_id'    => $request->user_id,
                'package_id' => $packageId,
                'mode'       => 'one',
            ]);

        } elseif ($request->mode === 'multi') {
            $request->validate([
                'packages'   => 'required|array|min:1',
                'packages.*' => 'exists:packages,id',
            ]);

            foreach ($request->packages as $packageId) {
                $exists = UserPackage::where('user_id', $request->user_id)
                                    ->where('package_id', $packageId)
                                    ->exists();

                if ($exists) {
                    return response()->json([
                        'status'  => false,
                        'message' => "Package already assigned (ID: {$packageId})!",
                    ], 422);
                }

                UserPackage::create([
                    'user_id'    => $request->user_id,
                    'package_id' => $packageId,
                    'mode'       => 'multi',
                ]);
            }
        }

        return response()->json([
            'status'  => true,
            'message' => 'Contract assigned successfully!',
        ]);
    }

    public function destroy($id){
        UserPackage::where('user_id', $id)->delete();
        return redirect()->back()->with('success','Contract for this user have been deleted successfully!');
    }
}
