<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UserPayment;
use App\Models\UserSubscription;

class AdminPaymentController extends Controller
{
    public function index(){
        $payments = UserPayment::with(['user', 'subscription.package', 'subscription.plan'])
            ->latest()
            ->get();

        $paymentsGrouped = $payments->groupBy('subscription_id');
        return view('admin.pages.payment.index', compact('paymentsGrouped'));
    }

    public function view($subscriptionId){
        $subscription = UserSubscription::with(['user', 'package', 'plan', 'payments'])->findOrFail($subscriptionId);

        $payments = $subscription->payments()->latest()->get();

        return view('admin.pages.payment.view', compact('subscription', 'payments'));
    }
}
