<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\UserPackage;
use App\Models\UserSubscription;

class AdminController extends Controller
{
    public function index()
    {
        $totalUsers = User::where('role','user')->count();

        $totalAssinged = UserPackage::distinct('user_id')->count();

        $pendingContract = UserSubscription::where('status','!=','completed')->count();

        $completedContract = UserSubscription::where('status','completed')->count();

        return view('admin.pages.dashboard', compact(
            'totalUsers', 
            'totalAssinged', 
            'pendingContract', 
            'completedContract'
        ));
    }
}
