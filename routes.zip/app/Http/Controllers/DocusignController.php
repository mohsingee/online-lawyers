<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DocuSign\eSign\Model\EnvelopeDefinition;
use Illuminate\Support\Facades\Auth;
use DocuSign\eSign\Api\EnvelopesApi;
use DocuSign\eSign\Model\Recipients;
use DocuSign\eSign\Client\ApiClient;
use Illuminate\Support\Facades\File;
use DocuSign\eSign\Model\SignHere;
use DocuSign\eSign\Model\Document;
use App\Models\DocusignConnection;
use DocuSign\eSign\Configuration;
use DocuSign\eSign\Model\Signer;
use DocuSign\eSign\Model\Tabs;
use App\Models\UserAgreement;
use App\Models\PackagePlan;
use App\Models\UserSubscription;
use App\Models\Package;
use Carbon\Carbon;
use Exception;
use Redirect;
use DateTime;
use Session;
use Mail;
use PDF;

class DocusignController extends Controller
{
    private $config;

    private $args;

    public function index(){
        $user = Auth::user();
        if($user->role=="user"){
            $token = DocusignConnection::latest()->first();
            $user_agreement = UserAgreement::with('plan')->where('user_id',$user->id)->latest()->first();


            $config = new Configuration();
            $config->setHost($token->base_url);
            $config->addDefaultHeader("Authorization", "Bearer " . $token->access_token);

            $apiClient = new ApiClient($config);
            $envelopeApi = new EnvelopesApi($apiClient);

            $envelope = $envelopeApi->getEnvelope($token->account_id, $user_agreement->envelope_id);

            $status = $envelope->getStatus();

            UserAgreement::where('user_id',$user->id)->update([
                'status'=>$status
            ]);

            $price = $user_agreement->plan->price;
            $installments = $user_agreement->plan->type ?: 1;

            $plan = PackagePlan::with('package')->where('id',$user_agreement->plan_id)->first();
            UserSubscription::create([
                'user_id' => $user->id,
                'package_id' => $plan->package_id,
                'plan_id' => $user_agreement->plan_id,
                'subscription_type' => $installments === 1 ? 'full' : 'installment',
                'total_installments' => $installments,
                'total_amount' => $plan->package->price,
                'installment_amount' => $price,
                'start_date' => now(),
                'end_date' => now()->addMonths($installments - 1),
            ]);

            return redirect()->route('payment.index')->with('success','You have successfully signed the contract!');
        }else{
            if(Session::get('access_token')){
                $currentDateTime = Carbon::now();
                $newDateTime = Carbon::now()->addDays(29);
                DocusignConnection::query()->update([
                    'access_token' => Session::get('access_token'),
                    'refresh_token' => Session::get('refresh_token'),
                    'expiry_date'   => $newDateTime,
                    'status'        => 'active',
                ]);
                Session::forget('access_token');
                Session::forget('refresh_token');
                return redirect()->route('admin.dashboard')->with('success','You have successfully connected your account to DocuSign.');
            }else{
                $tokenRefreshed = $this->tokenRefreshed();
                $isConnected = ($tokenRefreshed === true || $tokenRefreshed === "true");
                
                return view('admin.pages.docusign', compact('isConnected'));
            }
        }
    }
    
    public function connectDocusign(){
        $token = DocusignConnection::latest()->first();
        try {
            $params = [
                'response_type' => 'code',
                'scope' => 'signature',
                'client_id' => $token->client_id,
                'state' => 'a39fh23hnf23',
                'redirect_uri' => route('docusign.callback'),
            ];
            $queryBuild = http_build_query($params);
            $url = "https://account-d.docusign.com/oauth/auth?";
            $botUrl = $url . $queryBuild;
            return redirect()->to($botUrl);
        } catch (Exception $e) {
            return redirect()->back()->with('error', 'Oops! Something went wrong!');
        }
    }

    public function callback(Request $request){
        $token = DocusignConnection::latest()->first();

        $code = $request->code;

        $client_id = $token->client_id;
        $client_secret = $token->secret_id;
        $integrator_and_secret_key = "Basic " . utf8_decode(base64_encode("{$client_id}:{$client_secret}"));

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://account-d.docusign.com/oauth/token');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        $post = array(
            'grant_type' => 'authorization_code',
            'code' => $code,
        );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        $headers = array();
        $headers[] = 'Cache-Control: no-cache';
        $headers[] = "authorization: $integrator_and_secret_key";
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);
        $decodedData = json_decode($result);
        
        $request->session()->put('access_token', $decodedData->access_token);
        $request->session()->put('refresh_token', $decodedData->refresh_token);
        return redirect()->route('docusign');
    }

    private function tokenRefreshed(){
        try {
            $token = DocusignConnection::latest()->first();
            if($token=='') {
                return redirect()->back()->with('error', 'Oops! Admin has not connected the DocuSign account. Please contact the admin for assistance.');
            }
            $now = new DateTime();
            $tokenDate = new DateTime($token->expiry_date);
            if($now > $tokenDate) {
                return redirect()->back()->with('error', 'Oops! Something went wrong!');
            }
            
            $client_id = $token->client_id;
            $client_secret = $token->secret_id;

            $integrator_and_secret_key = "Basic " . utf8_decode(base64_encode("{$client_id}:{$client_secret}"));

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://account-d.docusign.com/oauth/token');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            $post = array(
                'grant_type' => 'refresh_token',
                'refresh_token' => $token->refresh_token,
            );
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

            $headers = array();
            $headers[] = 'Cache-Control: no-cache';
            $headers[] = "authorization: $integrator_and_secret_key";
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $refreshToken = curl_exec($ch);
            if (curl_errno($ch)) {
                echo 'Error:' . curl_error($ch);
            }
            curl_close($ch);
            $decodedData = json_decode($refreshToken);
            $newDateTime = Carbon::now()->addDays(29);
            if(isset($decodedData->access_token)){
                DocusignConnection::query()->update([
                    'access_token'=>$decodedData->access_token,
                    'refresh_token'=>$decodedData->refresh_token,
                    'expiry_date'=>$newDateTime,
                    'status'        => 'active',
                ]);

                return true;
            }
        } catch (\Exception $e) {
            \Log::error('Token refresh failed: ' . $e->getMessage());
            return false;
        }
    }

    public function signDocument(Request $request){
        ini_set('max_execution_time', 300);
        $plan = PackagePlan::find($request->plan_id);

        if (!$plan) {
            return redirect()->back()->with('error', 'Plan does not exist, please contact the admin!');
        }

        $user = Auth::user();

        $tokenRefreshed = $this->tokenRefreshed();

        if ($tokenRefreshed === false) {
            return redirect()->back()->with('error','Docusign not connected propely please contact the admin.');
        }

        try{
            $this->args = $this->getTemplateArgs();
            $args = $this->args;
            $envelope_args = $args["envelope_args"];

            $envelope_definition = $this->makeEnvelopeFileObject($args["envelope_args"],$plan);
            $envelope_api = $this->getEnvelopeApi();

            $api_client = new \DocuSign\eSign\client\ApiClient($this->config);
            $envelope_api = new \DocuSign\eSign\Api\EnvelopesApi($api_client);
            $results = $envelope_api->createEnvelope($args['account_id'], $envelope_definition);
            $envelopeId = $results->getEnvelopeId();
            $authentication_method = 'None';

            UserAgreement::create([
                'user_id'=>$user->id,
                'plan_id'=>$plan->id,
                'envelope_id'=>$envelopeId
            ]);

            $recipient_view_request = new \DocuSign\eSign\Model\RecipientViewRequest([
                'authentication_method' => $authentication_method,
                'client_user_id' => $envelope_args['signer_client_id'],
                'recipient_id' => '1',
                'return_url' => $envelope_args['ds_return_url'],
                'user_name' => $user->name, 'email' => $user->email

            ]);

            $results = $envelope_api->createRecipientView($args['account_id'], $envelopeId, $recipient_view_request);
            return redirect()->to($results['url']);
        } catch (Exception $e) {
            return redirect()->back()->with('error', 'Oops! Something went wrong!');
        }
    }

    private function makeEnvelopeFileObject($args,$plan){
        if ($plan->package->name === "Scholarship Agreement") {
            $name = "scholarship";
        } elseif ($plan->package->name === "EssayAssistance Agreement") {
            $name = "essayassistance";
        } elseif ($plan->package->name === "Bootcamp Agreement") {
            $name = "bootcamp";
        } elseif ($plan->package->name === "Friends & Family Agreement") {
            $name = "familyfriends";
        } else {
            $name = "comprehensive";
        }

        $user = Auth::user();

        // First Document
        $html1 = view('contracts.' . $name . '.cover_letter', compact('user'))->render();
        $pdfFile1 = \PDF::loadHTML($html1)->output();
        $base64File1 = base64_encode($pdfFile1);

        $document1 = new Document([
            'document_base64' => $base64File1,
            'name' => 'Scholarship Cover Letter',
            'file_extension' => 'pdf',
            'document_id' => '1'
        ]);

        // Second Document
        $html2 = view('contracts.' . $name . '.contract', compact('user','plan'))->render();
        $pdfFile2 = \PDF::loadHTML($html2)->output();
        $base64File2 = base64_encode($pdfFile2);

        $document2 = new Document([
            'document_base64' => $base64File2,
            'name' => 'Scholarship Agreement',
            'file_extension' => 'pdf',
            'document_id' => '2'
        ]);

        // Signer
        $signer = new Signer([
            'email' => $user->email,
            'name' => $user->name,
            'recipient_id' => '1',
            'routing_order' => '1',
            'client_user_id' => $args['signer_client_id'],
        ]);

        // 🔹 Anchor-based SignHere (wherever **signature** is found in PDF text)
        $signHere = new SignHere([
            'anchor_string' => '**signature**',   // must match text in PDF
            'anchor_units' => 'pixels',
            'anchor_y_offset' => '10',
            'anchor_x_offset' => '20'
        ]);

        // Attach tabs to signer
        $signer->setTabs(new Tabs([
            'sign_here_tabs' => [$signHere]
        ]));

        // Envelope
        $envelopeDefinition = new EnvelopeDefinition([
            'email_subject' => "Please sign this document sent from CollegeConnect101",
            'documents' => [$document1, $document2],
            'recipients' => new Recipients(['signers' => [$signer]]),
            'status' => "sent",
        ]);

        return $envelopeDefinition;
    }

    private function getTemplateArgs(){   
        $token = DocusignConnection::latest()->first();
        $envelope_args = [
            'signer_client_id' => rand(1111111,9999999),
            'ds_return_url' => route('docusign')
        ];
        $args = [
            'account_id' => $token->account_id,
            'base_path' => $token->base_url,
            'ds_access_token' => $token->access_token,
            'envelope_args' => $envelope_args
        ];
        return $args;
    }

    public function getEnvelopeApi(): EnvelopesApi{   
        $this->config = new Configuration();
        $this->config->setHost($this->args['base_path']);
        $this->config->addDefaultHeader('Authorization', 'Bearer ' . $this->args['ds_access_token']);    
        $this->apiClient = new ApiClient($this->config);
        return new EnvelopesApi($this->apiClient);
    }
}