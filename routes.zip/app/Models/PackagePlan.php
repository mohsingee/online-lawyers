<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PackagePlan extends Model
{
    protected $fillable = ['package_id', 'title', 'price', 'type'];

    public function package()
    {
        return $this->belongsTo(Package::class);
    }
}
