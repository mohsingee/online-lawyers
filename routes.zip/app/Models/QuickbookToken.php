<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuickbookToken extends Model
{
    protected $guarded = ['id'];
}
