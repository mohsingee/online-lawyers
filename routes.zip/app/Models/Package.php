<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Package extends Model
{
    protected $fillable = ['name'];

    public function plans()
    {
        return $this->hasMany(PackagePlan::class);
    }

    public function userPackages(){
        return $this->hasMany(UserPackage::class);
    }
}
