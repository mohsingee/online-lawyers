<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DocusignConnection extends Model
{
    protected $fillable = ['account_id','access_token','refresh_token','status','expiry_date'];
}
