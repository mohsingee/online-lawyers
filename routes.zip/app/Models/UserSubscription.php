<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserSubscription extends Model
{
    protected $guarded = ['id'];

    public function package(){
        return $this->belongsTo(Package::class, 'package_id');
    }

    public function plan(){
        return $this->belongsTo(PackagePlan::class, 'plan_id');
    }

    public function user(){
        return $this->belongsTo(User::class, 'user_id');
    }

    public function payments(){
        return $this->hasMany(UserPayment::class, 'subscription_id');
    }
}
